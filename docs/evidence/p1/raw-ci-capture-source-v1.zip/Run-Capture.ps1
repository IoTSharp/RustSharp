param([Parameter(Mandatory)][string]$Exe,[Parameter(Mandatory)][string]$ArgumentsFile,[Parameter(Mandatory)][string]$CallerLeaseRoot,[Parameter(Mandatory)][string]$Lease,[Parameter(Mandatory)][string]$ReviewedAssemblySha256,[ValidateRange(1,1073741824)][long]$MaximumBytes=268435456,[ValidateRange(1,16)][int]$MaximumProcesses=4,[Parameter(Mandatory)][switch]$RootApproved)
Set-StrictMode -Version 3.0;$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -lt 7 -or -not $RootApproved){throw 'PowerShell7/root approval required'}
$assembly=Join-Path $PSScriptRoot 'runtime\CaptureLauncher.dll'
if((Get-FileHash -LiteralPath $assembly).Hash -cne $ReviewedAssemblySha256){throw 'Exact freshly root-built assembly required'}
$root=[IO.Path]::GetFullPath($CallerLeaseRoot);if($root -cne $CallerLeaseRoot -or -not [IO.Directory]::Exists($root)){throw 'Existing exact caller lease root required'}
$owner=Get-Content -LiteralPath (Join-Path $root 'OWNER.json') -Raw|ConvertFrom-Json -DateKind String
if($owner.lease -cne $Lease -or $Lease -notmatch '^[a-f0-9]{32}$'){throw 'Exact caller lease identity required'}
if((Get-Item -LiteralPath $ArgumentsFile).Length -gt 65536){throw 'Arguments64KiB'}
[string[]]$argv=@(Get-Content -LiteralPath $ArgumentsFile -Raw|ConvertFrom-Json -DateKind String)
if($argv.Count -gt 24){throw 'Arguments24 bound'}
$loaded=[Reflection.Assembly]::LoadFile($assembly)
if($loaded.Location -cne $assembly){throw 'Loaded assembly path differs'}
$out=Join-Path $root 'stdout.bin';$err=Join-Path $root 'stderr.bin';$receipt=Join-Path $root 'capture-receipt.json'
if([IO.File]::Exists($receipt)){throw 'Fresh receipt required'}
$persistState=@{Count=0;Clock=[Diagnostics.Stopwatch]::StartNew();Errors=[Collections.Generic.List[string]]::new()}
function Write-CapturePhase([object]$entry,[string]$kind){
 if($persistState.Count -ge 8 -or $persistState.Clock.Elapsed.TotalSeconds -ge 8){throw 'Launch receipt8events/8seconds'}
 $persistState.Count++;$phasePath=Join-Path $root ('launch-'+$kind+'-'+$persistState.Count.ToString('D2')+'.json');$phaseBytes=[Text.UTF8Encoding]::new($false).GetBytes(($entry|ConvertTo-Json -Depth 12));if($phaseBytes.Length -gt 131072){throw 'Launch receipt128KiB'}
 $phaseStream=[IO.File]::Open($phasePath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$phaseStream.Write($phaseBytes);$phaseStream.Flush($true)}finally{$phaseStream.Dispose()}
}
$persist=[Action[FormatterPrivateConsoleFixture.LaunchReceipt]]{param($entry) Write-CapturePhase $entry 'phase'}
$clock=[Diagnostics.Stopwatch]::StartNew();$cancel=[Threading.CancellationTokenSource]::new([TimeSpan]::FromSeconds(30));$job=$null;$process=$null;$failure=$null;$secondary=@();$observed=@{};$exit=$null;$cleanup=$null;$controller=[FormatterPrivateConsoleFixture.ProcessAudit]::Read([uint32]$PID)
try{
 $job=[FormatterPrivateConsoleFixture.JobLease]::new()
 $process=[FormatterPrivateConsoleFixture.OwnedSuspendedProcess]::StartCaptured($Exe,$argv,$root,$job,$out,$err,$persist)
 $process.Recheck();$process.Resume()
 for($iteration=0;$iteration -lt 600 -and $clock.Elapsed.TotalSeconds -lt 30;$iteration++){
  $cancel.Token.ThrowIfCancellationRequested();$snapshot=$job.Inspect()
  if($snapshot.Overflow -or $snapshot.Total -gt $MaximumProcesses -or $snapshot.Active -gt $MaximumProcesses){throw 'Capture owned-job process quota'}
  foreach($member in @($snapshot.Members)){$observed[([string]$member.Pid+':'+[string]$member.CreationFileTime)]=$member}
  if((Get-Item -LiteralPath $out).Length -gt $MaximumBytes -or (Get-Item -LiteralPath $err).Length -gt $MaximumBytes){throw 'Raw byte quota'}
  if($process.HasExited()){if(-not $process.Wait(1,$cancel.Token)){throw 'Native exit read deadline'};$exit=$process.ExitCode;break}
  if(($iteration%100) -eq 0){Write-Information ('capture progress '+$iteration) -InformationAction Continue};Start-Sleep -Milliseconds 50
 }
 if($null -eq $exit){throw 'Capture1attempt/600polls/30seconds deadline'}
 foreach($path in @($out,$err)){if((Get-Item -LiteralPath $path).Length -gt $MaximumBytes){throw 'Natural exit raw byte quota'}}
}catch{
 $failure=$_.ToString();$exception=$_.Exception;$exceptionClock=[Diagnostics.Stopwatch]::StartNew()
 for($depth=0;$exception -and $depth -lt 8 -and $exceptionClock.Elapsed.TotalSeconds -lt 2;$depth++){
  if($exception -is [FormatterPrivateConsoleFixture.LaunchException]){try{Write-CapturePhase $exception.Receipt 'failure'}catch{$persistState.Errors.Add($_.ToString())};break};$exception=$exception.InnerException
 }
}finally{
 if($job){try{$cleanup=$job.Reap([Threading.CancellationToken]::None)}catch{$secondary+=@($_.ToString())}}
 if($process){try{$process.Dispose()}catch{$secondary+=@($_.ToString())}}
 if($job){try{$job.Dispose()}catch{$secondary+=@($_.ToString())}}
 $cancel.Dispose();$files=@();foreach($path in @($out,$err)){if([IO.File]::Exists($path)){$finalBytes=(Get-Item -LiteralPath $path).Length;if($finalBytes -gt $MaximumBytes){$secondary+=@('Final raw byte quota exceeded '+$path);if(-not $failure){$failure='Final raw byte quota exceeded'}};$files+=@{path=$path;bytes=$finalBytes;sha256=(Get-FileHash -LiteralPath $path).Hash}}}
 $record=@{lease=$Lease;controller=$controller;exe=$Exe;arguments=$argv;actualExit=$exit;launch=if($process){$process.Receipt}else{$null};observedMembers=@($observed.Values);cleanup=$cleanup;files=$files;error=$failure;secondary=$secondary;launchReceiptCount=$persistState.Count;launchReceiptErrors=@($persistState.Errors.ToArray());rawBinaryCapture=$true;originalScopePassed=$false;fullP1Closure=$false;elapsedSeconds=$clock.Elapsed.TotalSeconds}
 $stream=[IO.File]::Open($receipt,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($record|ConvertTo-Json -Depth 16));$stream.Write($bytes)}finally{$stream.Dispose()}
}
if($failure){throw $failure};if($exit -ne 0 -or -not $cleanup.AccountingZero -or $cleanup.HandleClosed -ne $true){throw 'Command exit or complete Job cleanup failed; raw files retained'}