[CmdletBinding()]
param(
 [Parameter(Mandatory)][string]$TinyDll,
 [Parameter(Mandatory)][string]$ReceiptParent,
 [Parameter(Mandatory)][string]$CancelFile,
 [Parameter(Mandatory)][string]$DotnetPath,
 [Parameter(Mandatory)][string]$StatPath,
 [Parameter(Mandatory)][string]$TimeoutPath
)
$ErrorActionPreference='Stop'
if(!$IsLinux -or $PSVersionTable.PSVersion.Major -lt 7){throw 'Linux PowerShell >=7 required'}
$runClock=[Diagnostics.Stopwatch]::StartNew()
foreach($value in @($TinyDll,$ReceiptParent,$CancelFile,$DotnetPath,$StatPath,$TimeoutPath)) {if(![IO.Path]::IsPathFullyQualified($value)){throw 'Every supplied path must be absolute'}}
foreach($value in @($TinyDll,$DotnetPath,$StatPath,$TimeoutPath)) {if(!(Test-Path -LiteralPath $value -PathType Leaf)){throw "Missing explicit input: $value"}}
if(!(Test-Path -LiteralPath $ReceiptParent -PathType Container)){throw 'Existing receipt parent required'}
$leaseId=[Guid]::NewGuid().ToString('N')
$hostLease=Join-Path $ReceiptParent ('identity-native-v4-'+$leaseId)
$lease=Join-Path '/tmp' ('rustsharp-identity-v4-'+$leaseId)
if(Test-Path -LiteralPath $hostLease){throw 'Host lease collision'}
[IO.Directory]::CreateDirectory($hostLease)|Out-Null
[IO.File]::WriteAllText((Join-Path $hostLease 'owner.lease'),$leaseId)
if(Test-Path -LiteralPath $lease){throw 'Lease collision'}
[IO.Directory]::CreateDirectory($lease)|Out-Null
$leaseMarker=Join-Path $lease 'owner.lease'
$owner=[IO.FileStream]::new($leaseMarker,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$owner.Write([Text.Encoding]::ASCII.GetBytes($leaseId))}finally{$owner.Dispose()}
$owned=[Collections.Generic.Dictionary[int,object]]::new()
$processHistory=[Collections.Generic.List[object]]::new()
$cleanup=[Collections.Generic.List[object]]::new()
$headerReceipts=[Collections.Generic.List[object]]::new()
$tinyChildPostChecks=[Collections.Generic.List[object]]::new()
$failure=$null;$process=$null;$exitCode=$null;$stdoutTask=$null;$stderrTask=$null;$startIdentity=$null
function Read-Identity([int]$ProcessId){
 try {
  $statPath='/proc/'+$ProcessId+'/stat'
  $raw=[IO.File]::ReadAllText($statPath)
  $close=$raw.LastIndexOf(')');if($close -lt 1){return $null}
  $tail=$raw.Substring($close+2).Split(' ',[StringSplitOptions]::RemoveEmptyEntries)
  if($tail.Length -lt 20){return $null}
  $cmdBytes=[IO.File]::ReadAllBytes('/proc/'+$ProcessId+'/cmdline')
  if($cmdBytes.Length -gt 32768){throw 'Process command line over bound'}
  [pscustomobject]@{pid=$ProcessId;parentPid=[int]$tail[1];state=$tail[0];processGroup=[int]$tail[2];session=[int]$tail[3];startTicks=$tail[19];rawStat=$raw;rawCommandBase64=[Convert]::ToBase64String($cmdBytes);commandArguments=@([Text.Encoding]::UTF8.GetString($cmdBytes).Split([char]0,[StringSplitOptions]::RemoveEmptyEntries));observedUtc=[DateTimeOffset]::UtcNow.ToString('o')}
 } catch [IO.IOException] {return $null} catch [UnauthorizedAccessException] {return $null}
}
function Read-ParentChain([object]$Identity){
 $chain=[Collections.Generic.List[object]]::new();$item=$Identity
 for($depth=0;$depth -lt 32 -and $null -ne $item;$depth++){$chain.Add($item);if($item.parentPid -le 0){break};$item=Read-Identity $item.parentPid}
 return ,@($chain.ToArray())
}
function Get-OwnedDepth([object]$Identity){
 $depth=0;$cursor=$Identity
 for($n=0;$n -lt 16 -and $owned.ContainsKey($cursor.parentPid);$n++){$depth++;$cursor=$owned[$cursor.parentPid]};return $depth
}
function Test-Same([object]$Known,[object]$Actual){
 return $null -ne $Actual -and $Known.pid -eq $Actual.pid -and $Known.startTicks -ceq $Actual.startTicks -and $Known.rawCommandBase64 -ceq $Actual.rawCommandBase64
}
function Observe-Owned {
 $inventoryClock=[Diagnostics.Stopwatch]::StartNew()
 $table=[Collections.Generic.Dictionary[int,object]]::new()
 $items=@([Diagnostics.Process]::GetProcesses())
 if($items.Count -gt 1024){foreach($item in $items){$item.Dispose()};throw 'Process inventory exceeds 1024 cap'}
 foreach($item in $items){try{if($inventoryClock.Elapsed.TotalSeconds -ge 2){throw 'Process inventory wall exceeded two seconds'};$identity=Read-Identity $item.Id;if($null -ne $identity){$table[$identity.pid]=$identity}}finally{$item.Dispose()}}
 # At most 16 generations of the source-reviewed timeout -> dotnet -> stat tree.
 for($depth=0;$depth -lt 16;$depth++){
  $added=0
  foreach($identity in $table.Values){
   if($inventoryClock.Elapsed.TotalSeconds -ge 2){throw 'Process ancestry inventory wall exceeded two seconds'}
   if(!$owned.ContainsKey($identity.pid) -and $owned.ContainsKey($identity.parentPid)){
    $knownParent=$owned[$identity.parentPid];$actualParent=$table[$identity.parentPid]
    if(Test-Same $knownParent $actualParent){$owned.Add($identity.pid,$identity);$processHistory.Add([pscustomobject]@{identity=$identity;parentChain=Read-ParentChain $identity});$added++}
   }
  }
  if($added -eq 0){break}
 }
}
try {
 $hostIdentity=Read-Identity $PID
 [pscustomobject]@{schemaVersion=1;lease=$lease;hostLease=$hostLease;filesystemRoot='/tmp';leaseId=$leaseId;guestHost=$hostIdentity;parentChain=Read-ParentChain $hostIdentity;powerShell=$PSVersionTable.PSVersion.ToString();tinyDll=$TinyDll;tinyDllSha256=(Get-FileHash -LiteralPath $TinyDll -Algorithm SHA256).Hash;tools=@{dotnet=$DotnetPath;stat=$StatPath;timeout=$TimeoutPath};limits=@{snapshots=3;appWallSeconds=5;timeoutKillAfterSeconds=1;polls=120;pollWallSeconds=7;processInventory=1024;parentDepth=32;ownedDepth=16};fullContainmentPhaseAccepted=$false} | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $lease 'invocation.json') -Encoding utf8NoBOM
 $headerPlan=@(@{path='/usr/include/linux/stat.h';lines=170},@{path='/usr/include/x86_64-linux-gnu/bits/statx-generic.h';lines=20})
 for($n=0;$n -lt 2;$n++){
  if($runClock.Elapsed.TotalSeconds -ge 15 -or (Test-Path -LiteralPath $CancelFile)){throw 'Cancelled or preparation deadline reached'}
  $plan=$headerPlan[$n];$exists=Test-Path -LiteralPath $plan.path -PathType Leaf
  $text=if($exists){@(Get-Content -LiteralPath $plan.path -TotalCount $plan.lines)}else{@()}
  $digest=if($exists){(Get-FileHash -LiteralPath $plan.path -Algorithm SHA256).Hash}else{$null}
  $out=Join-Path $lease ('header-'+$n+'.txt');[IO.File]::WriteAllLines($out,[string[]]$text)
  $headerReceipts.Add([pscustomobject]@{path=$plan.path;exists=$exists;maximumLines=$plan.lines;capturedLines=$text.Count;sourceSha256=$digest;capturedPath=$out;capturedSha256=(Get-FileHash -LiteralPath $out -Algorithm SHA256).Hash})
 }
 $headerReceipts | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $lease 'headers.json') -Encoding utf8NoBOM
 if(Test-Path -LiteralPath $CancelFile){throw [OperationCanceledException]::new('Cancelled before launch')}
 $fsStart=[Diagnostics.ProcessStartInfo]::new($StatPath);$fsStart.UseShellExecute=$false;$fsStart.RedirectStandardOutput=$true;$fsStart.RedirectStandardError=$true
 foreach($arg in @('--file-system','--printf=type=%T id=%i blockSize=%S blocks=%b available=%a nameLength=%l\n','--','/tmp')){$fsStart.ArgumentList.Add($arg)}
 $fsProcess=[Diagnostics.Process]::Start($fsStart);$fsIdentity=$null;$fsExit=$null;$fsOut='';$fsError=''
 try{
  $fsIdentity=Read-Identity $fsProcess.Id
  if($null -ne $fsIdentity){$owned[$fsIdentity.pid]=$fsIdentity;$processHistory.Add([pscustomobject]@{identity=$fsIdentity;parentChain=Read-ParentChain $fsIdentity;source='filesystem-stat'})}
  if(!$fsProcess.WaitForExit(1000)){throw 'Filesystem stat exceeded one second'}
  $fsExit=$fsProcess.ExitCode;$fsOut=$fsProcess.StandardOutput.ReadToEnd();$fsError=$fsProcess.StandardError.ReadToEnd()
  if($fsExit -ne 0){throw 'Filesystem stat failed'}
 }finally{
  if(!$fsProcess.HasExited -and $null -ne $fsIdentity -and (Test-Same $fsIdentity (Read-Identity $fsIdentity.pid))){$fsProcess.Kill();[void]$fsProcess.WaitForExit(300)}
  [pscustomobject]@{path='/tmp';fixtureLease=$lease;identity=$fsIdentity;arguments=@($fsStart.ArgumentList);exitCode=$fsExit;stdout=$fsOut;stderr=$fsError;after=$(if($null -ne $fsIdentity){Read-Identity $fsIdentity.pid}else{$null})} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $lease 'filesystem.json') -Encoding utf8NoBOM
  $fsProcess.Dispose()
 }
 $start=[Diagnostics.ProcessStartInfo]::new($TimeoutPath)
 $start.UseShellExecute=$false;$start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true;$start.WorkingDirectory=$lease
 foreach($arg in @('--signal=TERM','--kill-after=1s','5s',$DotnetPath,$TinyDll,$lease,$CancelFile,$StatPath)){$start.ArgumentList.Add($arg)}
 $process=[Diagnostics.Process]::Start($start)
 if($null -eq $process){throw 'Native tiny failed to start'}
 $stdoutTask=$process.StandardOutput.ReadToEndAsync();$stderrTask=$process.StandardError.ReadToEndAsync()
 $startIdentity=Read-Identity $process.Id
 if($null -eq $startIdentity -or $startIdentity.parentPid -ne $PID){throw 'Cannot establish root process identity'}
 $owned.Add($startIdentity.pid,$startIdentity);$processHistory.Add([pscustomobject]@{identity=$startIdentity;parentChain=Read-ParentChain $startIdentity})
 $pollClock=[Diagnostics.Stopwatch]::StartNew();$nextProgress=1.0
 for($poll=0;$poll -lt 120 -and $pollClock.Elapsed.TotalSeconds -lt 7;$poll++){
  Observe-Owned
  if(Test-Path -LiteralPath $CancelFile){throw [OperationCanceledException]::new('Cancelled during tiny')}
  if($process.HasExited){$exitCode=$process.ExitCode;break}
  if($pollClock.Elapsed.TotalSeconds -ge $nextProgress){Write-Host ('tiny progress: '+[Math]::Round($pollClock.Elapsed.TotalSeconds,1)+'s / 7s; owned='+$owned.Count);$nextProgress+=1}
  Start-Sleep -Milliseconds $(if($poll -lt 20){50}else{100})
 }
 if($null -eq $exitCode){throw 'Native tiny wrapper exceeded 120 polls or seven-second wall'}
 if($exitCode -ne 0){throw "Native tiny wrapper exit $exitCode"}
} catch {if($null -eq $failure){$failure=$_.ToString()}else{$failure+="`n"+$_.ToString()}}
finally {
 if($null -ne $startIdentity){try{Observe-Owned}catch{$cleanup.Add([pscustomobject]@{operation='final-inventory';error=$_.ToString()})}}
 # Source-reviewed tree has at most timeout, dotnet and three synchronous stat processes.
 # Only observed identities still matching PID, birth ticks and raw command are eligible.
 $cleanupClock=[Diagnostics.Stopwatch]::StartNew()
 $candidates=@($owned.Values | Sort-Object -Property @{Expression={Get-OwnedDepth $_};Descending=$true})
 if($candidates.Count -gt 32){$failure='Owned tree exceeded 32-object cleanup cap';$candidates=@($candidates | Select-Object -First 32)}
 foreach($known in $candidates){
  if($cleanupClock.Elapsed.TotalSeconds -ge 3){$cleanup.Add([pscustomobject]@{pid=$known.pid;operation='retained';reason='cleanup wall reached'});break}
  $actual=Read-Identity $known.pid
  if(Test-Same $known $actual){
   try{
    $parentStillKnown=$actual.parentPid -eq $PID -or $owned.ContainsKey($actual.parentPid) -or $actual.parentPid -eq 1
    if(!$parentStillKnown){$cleanup.Add([pscustomobject]@{pid=$known.pid;operation='retained';reason='parent chain changed outside owned tree'});continue}
    $p=[Diagnostics.Process]::GetProcessById($known.pid)
    try {if(Test-Same $known (Read-Identity $known.pid)){$p.Kill();[void]$p.WaitForExit(300);$cleanup.Add([pscustomobject]@{pid=$known.pid;operation='killed';identity=$known;after=Read-Identity $known.pid})}}finally{$p.Dispose()}
   }catch{$cleanup.Add([pscustomobject]@{pid=$known.pid;operation='cleanup-error';error=$_.ToString()})}
  }else{$cleanup.Add([pscustomobject]@{pid=$known.pid;operation='absent-or-identity-changed';after=$actual})}
 }
 if($null -ne $process){
  try{if($process.HasExited){if($null -ne $stdoutTask){if(!$stdoutTask.Wait(1000)){throw 'stdout drain exceeded one second'};[IO.File]::WriteAllText((Join-Path $lease 'tiny.stdout.log'),$stdoutTask.GetAwaiter().GetResult())};if($null -ne $stderrTask){if(!$stderrTask.Wait(1000)){throw 'stderr drain exceeded one second'};[IO.File]::WriteAllText((Join-Path $lease 'tiny.stderr.log'),$stderrTask.GetAwaiter().GetResult())}}}catch{if($null -eq $failure){$failure=$_.ToString()}else{$failure+="`n"+$_.ToString()}}finally{$process.Dispose()}
 }
 # Independently recheck every stat identity emitted by the source-reviewed tiny program.
 # This also accounts for short children that completed between /proc sampling rounds.
 $tinyFiles=@(Get-ChildItem -LiteralPath $lease -File -Filter 'identity-tiny-*.json' | Select-Object -First 2)
 if($tinyFiles.Count -eq 1){
  try {
   if($tinyFiles[0].Length -gt 131072){throw 'Tiny receipt exceeds 128KiB'}
   $tiny=Get-Content -LiteralPath $tinyFiles[0].FullName -Raw | ConvertFrom-Json -DateKind String
   if($exitCode -eq 0 -and (@($tiny.snapshots).Count -ne 3 -or @($tiny.processReceipts).Count -ne 0 -or $tiny.status -cne 'OBSERVED')){throw 'Successful tiny requires exactly three snapshots and zero external child receipts'}
   if(@($tiny.processReceipts).Count -gt 3){throw 'Tiny emitted more than three native child receipts'}
   foreach($child in @($tiny.processReceipts)){
    $actual=Read-Identity ([int]$child.pid)
    if($null -eq $actual){$tinyChildPostChecks.Add([pscustomobject]@{receipt=$child;operation='absent'});continue}
    $native=[Diagnostics.Process]::GetProcessById([int]$child.pid)
    try {
     $birthMatches=$native.StartTime.ToUniversalTime().Ticks -eq [DateTimeOffset]::Parse($child.birthUtc).UtcTicks
     $expectedArgs=@([string]$child.executable)+@($child.arguments)
     $cmdMatches=($expectedArgs -join [char]0) -ceq (@($actual.commandArguments) -join [char]0)
     $parentMatches=$actual.parentPid -eq [int]$child.parentPid -or $actual.parentPid -eq 1
     if($birthMatches -and $cmdMatches -and $parentMatches){
      if(!$owned.ContainsKey($actual.pid)){$owned.Add($actual.pid,$actual);$processHistory.Add([pscustomobject]@{identity=$actual;parentChain=Read-ParentChain $actual;source='tiny-child-receipt'})}
      if(Test-Same $actual (Read-Identity $actual.pid)){$native.Kill();[void]$native.WaitForExit(300)}
      $tinyChildPostChecks.Add([pscustomobject]@{receipt=$child;operation='identity-verified-cleanup';identity=$actual;after=Read-Identity $actual.pid})
     }else{$tinyChildPostChecks.Add([pscustomobject]@{receipt=$child;operation='foreign-or-reused-pid-retained';actual=$actual;birthMatches=$birthMatches;commandMatches=$cmdMatches;parentMatches=$parentMatches})}
    }finally{$native.Dispose()}
   }
  }catch{if($null -eq $failure){$failure=$_.ToString()}else{$failure+="`n"+$_.ToString()}}
 }else{if($null -ne $failure){$failure+="`n"};$failure+='Expected one preserved tiny JSON receipt; observed '+$tinyFiles.Count}
 $survivors=@($owned.Values | Where-Object {Test-Same $_ (Read-Identity $_.pid)})
 [pscustomobject]@{schemaVersion=1;taskId='P2-08.03.linux-identity-v4';status=$(if($null -eq $failure -and $survivors.Count -eq 0){'OBSERVED'}else{'FAILED'});lease=$lease;hostLease=$hostLease;filesystemRoot='/tmp';leaseId=$leaseId;elapsedMs=$runClock.Elapsed.TotalMilliseconds;exitCode=$exitCode;failure=$failure;processes=$processHistory;cleanup=$cleanup;tinyChildPostChecks=$tinyChildPostChecks;survivors=$survivors;shortChildReceiptSource='identity-tiny-<nonce>.json processReceipts records each synchronous stat; /proc samples may miss exited short children';fullContainmentPhaseAccepted=$false;fullLeafAccepted=$false;fullP2Closure=$false} | ConvertTo-Json -Depth 18 | Set-Content -LiteralPath (Join-Path $lease 'guest-receipt.json') -Encoding utf8NoBOM
 # Copy only this verified nonce lease; preserve both source and destination originals.
 $transferClock=[Diagnostics.Stopwatch]::StartNew();$transfer=[Collections.Generic.List[object]]::new();$pending=[Collections.Generic.Stack[object]]::new();$pending.Push([pscustomobject]@{path=$lease;depth=0});$visited=0;$copyFailure=$null
 try{
  if([IO.File]::ReadAllText($leaseMarker) -cne $leaseId -or [IO.File]::ReadAllText((Join-Path $hostLease 'owner.lease')) -cne $leaseId){throw 'Transfer owner marker mismatch'}
  for($round=0;$round -lt 16 -and $pending.Count -gt 0;$round++){
   if($transferClock.Elapsed.TotalSeconds -ge 10 -or (Test-Path -LiteralPath $CancelFile)){throw 'Transfer deadline or cancellation'}
   $directory=$pending.Pop()
   foreach($entry in [IO.Directory]::EnumerateFileSystemEntries($directory.path)){
    if(++$visited -gt 32 -or $transferClock.Elapsed.TotalSeconds -ge 10){throw 'Transfer entry or wall bound reached'}
    $attributes=[IO.File]::GetAttributes($entry);if(($attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Transfer refuses reparse source'}
    $relative=[IO.Path]::GetRelativePath($lease,$entry);if($relative.StartsWith('..') -or [IO.Path]::IsPathRooted($relative)){throw 'Source escaped nonce lease'}
    if(($attributes -band [IO.FileAttributes]::Directory) -ne 0){if($directory.depth -ge 2){throw 'Transfer depth exceeds three'};$pending.Push([pscustomobject]@{path=$entry;depth=$directory.depth+1});continue}
    if($transfer.Count -ge 12){throw 'Transfer exceeds twelve files'}
    $target=Join-Path $hostLease $relative
    $sourceHash=(Get-FileHash -LiteralPath $entry -Algorithm SHA256).Hash
    if($relative -ceq 'owner.lease') {if([IO.File]::ReadAllText($target) -cne $leaseId){throw 'Host marker changed'}}
    else {if(Test-Path -LiteralPath $target){throw 'Unknown existing host target'};[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))|Out-Null;[IO.File]::Copy($entry,$target,$false)}
    $afterHash=(Get-FileHash -LiteralPath $entry -Algorithm SHA256).Hash;$targetHash=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
    if($sourceHash -cne $afterHash -or $sourceHash -cne $targetHash){throw 'Transferred original hash mismatch'}
    $transfer.Add([pscustomobject]@{source=$entry;target=$target;bytes=(Get-Item -LiteralPath $entry).Length;sha256=$sourceHash;targetSha256=$targetHash})
   }
  }
  if($pending.Count -ne 0){throw 'Transfer round bound reached'}
 }catch{$copyFailure=$_.ToString();if($null -eq $failure){$failure=$copyFailure}else{$failure+="`n"+$copyFailure}}
 $transferReceipt=[pscustomobject]@{lease=$lease;hostLease=$hostLease;leaseId=$leaseId;maximumFiles=12;maximumDepth=3;wallSeconds=10;files=$transfer;elapsedMs=$transferClock.Elapsed.TotalMilliseconds;failure=$copyFailure;bothOriginalsRetained=$true}
 $transferReceipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $hostLease 'transfer.json') -Encoding utf8NoBOM
 Write-Host ('hostLease='+$hostLease)
 Write-Host ('lease='+$lease)
}
if($null -ne $failure -or $survivors.Count -ne 0){exit 1}