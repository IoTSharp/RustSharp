using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Text.Json.Serialization;

if (!OperatingSystem.IsLinux() || args.Length != 3 || !Path.IsPathFullyQualified(args[0]) || !Path.IsPathFullyQualified(args[1])) throw new ArgumentException("Linux, absolute existing receipt root and cancel-file required; third stat path retained for argv compatibility.");
if (!Directory.Exists(args[0]) || Marshal.SizeOf<StatxBuffer>() != 256) throw new ArgumentException("Existing receipt root and verified 256-byte statx layout required.");
string nonce = Guid.NewGuid().ToString("N");
string parent = Path.Combine(args[0], "identity-tiny-" + nonce);
string child = Path.Combine(parent, "child");
string report = Path.Combine(args[0], "identity-tiny-" + nonce + ".json");
var wall = Stopwatch.StartNew();
var snapshots = new List<SnapshotReceipt>();
string? failure = null;
bool cancelled = false;
Console.CancelKeyPress += (_, e) => { e.Cancel = true; cancelled = true; };
try
{
 Directory.CreateDirectory(parent);
 for (int step = 0; step < 3; step++)
 {
  Check();
  if (step == 1) Directory.CreateDirectory(child);
  if (step == 2) File.WriteAllText(Path.Combine(child, "payload.txt"), "tiny\n");
  // Absolute pathname means dirfd is ignored; zero flags requires no guessed AT_* constants.
  // Mask and 256-byte layout are reconciled to real captured /usr/include/linux/stat.h.
  int result = Native.Statx(0, parent, 0, 0xFFF, out StatxBuffer data);
  int error = result == 0 ? 0 : Marshal.GetLastPInvokeError();
  if (result != 0) throw new IOException("statx errno=" + error);
  DateTime netBirth = Directory.GetCreationTimeUtc(parent);
  snapshots.Add(new SnapshotReceipt(step, step == 0 ? "parent-created" : step == 1 ? "child-directory-created" : "child-file-written", parent, netBirth.ToString("O"), netBirth.Ticks, new NativeSnapshot(data.Mask, data.DeviceMajor, data.DeviceMinor, data.Inode, (ushort)(data.Mode & 0xF000), new NativeTimestamp((data.Mask & 0x800) != 0, data.BirthSeconds, data.BirthNanoseconds), new NativeTimestamp((data.Mask & 0x80) != 0, data.ChangeSeconds, data.ChangeNanoseconds), new NativeTimestamp((data.Mask & 0x40) != 0, data.ModificationSeconds, data.ModificationNanoseconds)), wall.Elapsed.TotalMilliseconds));
  Console.WriteLine("snapshot " + (step + 1) + "/3 inode=" + data.Inode + " netBirthTicks=" + netBirth.Ticks);
  Check();
  if (step < 2) Thread.Sleep(25);
 }
}
catch (Exception e) { failure = e.ToString(); }
finally
{
 var receipt = new TinyReceipt(1, Environment.ProcessId, nonce, parent, args[1], args[2], 3, 5, 256, snapshots, Array.Empty<NativeProcessReceipt>(), wall.Elapsed.TotalMilliseconds, failure, failure is null ? "OBSERVED" : "FAILED", false);
 File.WriteAllText(report, JsonSerializer.Serialize(receipt, TinyJsonContext.Default.TinyReceipt));
 Console.WriteLine("receipt=" + report);
}
return failure is null ? 0 : 1;
void Check() { if (cancelled || File.Exists(args[1])) throw new OperationCanceledException("tiny cancelled"); if (wall.Elapsed >= TimeSpan.FromSeconds(5)) throw new TimeoutException("tiny exceeded five seconds"); }

internal sealed record NativeTimestamp(bool Available, long Seconds, uint Nanoseconds);
internal sealed record NativeSnapshot(uint Mask, uint DeviceMajor, uint DeviceMinor, ulong Inode, ushort Type, NativeTimestamp NativeBirth, NativeTimestamp Ctime, NativeTimestamp Mtime);
internal sealed record SnapshotReceipt(int Step, string Operation, string Path, string NetCreationUtc, long NetCreationTicks, NativeSnapshot Native, double ElapsedMs);
internal sealed record NativeProcessReceipt(int Pid);
internal sealed record TinyReceipt(int SchemaVersion, int Pid, string Nonce, string Parent, string CancelFile, string CompatibilityStatPath, int CountLimit, int WallLimitSeconds, int StatxBufferBytes, List<SnapshotReceipt> Snapshots, NativeProcessReceipt[] ProcessReceipts, double ElapsedMs, string? Failure, string Status, bool WholePublicationAccepted);
[JsonSourceGenerationOptions(PropertyNamingPolicy = JsonKnownNamingPolicy.CamelCase, WriteIndented = true)]
[JsonSerializable(typeof(TinyReceipt))]
internal sealed partial class TinyJsonContext : JsonSerializerContext { }
[StructLayout(LayoutKind.Explicit, Size = 256)]
internal struct StatxBuffer
{
 [FieldOffset(0)] internal uint Mask;
 [FieldOffset(28)] internal ushort Mode;
 [FieldOffset(32)] internal ulong Inode;
 [FieldOffset(80)] internal long BirthSeconds;
 [FieldOffset(88)] internal uint BirthNanoseconds;
 [FieldOffset(96)] internal long ChangeSeconds;
 [FieldOffset(104)] internal uint ChangeNanoseconds;
 [FieldOffset(112)] internal long ModificationSeconds;
 [FieldOffset(120)] internal uint ModificationNanoseconds;
 [FieldOffset(136)] internal uint DeviceMajor;
 [FieldOffset(140)] internal uint DeviceMinor;
}
internal static partial class Native
{
 [LibraryImport("libc", EntryPoint = "statx", StringMarshalling = StringMarshalling.Utf8, SetLastError = true)]
 internal static partial int Statx(int directory, string path, int flags, uint mask, out StatxBuffer buffer);
}