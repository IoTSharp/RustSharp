#!/usr/bin/env bash
set -euo pipefail
# All scripts are files with LF bytes. Never embed this shell text in an expandable PowerShell string.
[ "$#" -eq 4 ] || { printf '%s\n' 'Expected: absolute guest.ps1 tiny.dll receipt-parent cancel-file' >&2; exit 64; }
for input in "$@"; do case "$input" in /*) ;; *) printf '%s\n' 'All input paths must be absolute' >&2; exit 64;; esac; done
dotnet_path=$(command -v dotnet) || exit 69
stat_path=$(command -v stat) || exit 69
timeout_path=$(command -v timeout) || exit 69
pwsh_path=$(command -v pwsh) || exit 69
printf 'dotnet=%s\nstat=%s\ntimeout=%s\npwsh=%s\n' "$dotnet_path" "$stat_path" "$timeout_path" "$pwsh_path"
exec "$pwsh_path" -NoLogo -NoProfile -File "$1" -TinyDll "$2" -ReceiptParent "$3" -CancelFile "$4" -DotnetPath "$dotnet_path" -StatPath "$stat_path" -TimeoutPath "$timeout_path"