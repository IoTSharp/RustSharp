# Exact f463 native CI original review / 精确 f463 原生 CI 原件审查

✅ Bounded8+20 components match on both RIDs / 双RID有界8+20组件核对吻合

Exact candidate f463ac8fff710b11f851881437f9db864e4b42f6, workflow run38512774036, original run API attempt1. Linux job115684807319 and Windows job115684807497 are completed/success, with actual job labels ubuntu-24.04/windows-2025. Original binding has runId only; attempt/job/native OS provenance is supplemented from the separately hashed original run/jobs API. No absent runnerOS field is fabricated.
精确候选及run如上，真实run API attempt1；两个真实job完成成功，labels明确Ubuntu/Windows。原binding只有runId，attempt/job/native OS通过另行哈希的真实API补充；没有捏造缺失runnerOS字段。

Both originals show SDK10.0.400, PowerShell7.6.6, successful fresh all-solution nonincremental build. Every one of991 ordered source path/hash records matches before/after on each platform; six DLL/PDB physical files per platform match binding hashes. Workspace8 and API20 each execute/pass every ordered case with0failed/0notRun/error:56/56 across both RIDs. Each platform's eight actual child identities/exits/cleanup flags match; child parent PID, birth within runner lifetime, command fixture path, working directory and rsc.dll doc invocation also cross-link to the actual component runner. API and SDK process receipts bind the same dotnet host/fresh test DLL as applicable.
双原件SDK400、Pwsh7.6.6，全solution非增量fresh构建成功；各991条有序源码前后path/hash逐项一致，每平台6份DLL/PDB实物哈希吻合。两端8+20逐例完整执行/通过，共56/56，无失败/未运行/error。各8条实际子进程身份/退出/清理标志吻合，并与runner父PID、生命周期、原fixture路径、工作目录及rsc.dll doc命令交叉对应；API/SDK收据对应同一dotnet宿主/新test DLL。

Worker independently recomputed the two preserved ZIP hashes/sizes, matching Root's original archive receipt and recorded remote digest: Linux1A5EC24A7E4776C65C1F7AC78DF939D173411A4F577267B1281FF0EF6140C757 /2912994B; Windows52259A3273F4583A30FBE8883538DC8962F16505A88BA1C3D8EE199908FD5847 /3071433B. Root separately performed safe extraction; worker did not redownload or alter originals.
worker独立重算两原ZIP的哈希/大小，与监督者原收据及记录的remoteDigest一致；安全提取由监督者执行，worker未重新下载或改原件。

Limits remain explicit: this CI workflow runs8+20, not publication21. Local Windows/Linux21 evidence remains separate (local SDK402 versus CI400). Temporary fixture/source/page byte trees named in receiptRoots were not uploaded, so those original bytes cannot be independently rehashed from these CI archives. Build/helper cleanup declares parent-exit-only and does not prove full detached/malicious descendant containment. Runtime FD baseline/after is not measured. Component success does not close P2-08.03, P1 gates or P2 phase; all full closure flags remain false. Preserve old CI Linux failures,20 NOT_RUN,20/21 publication failure and every capture failure.
限制：本CI只跑8+20，未跑publication21；本地双平台21及SDK402与CI400分列。receiptRoots指向的临时fixture/source/page字节树未上传，故无法由CI archive独立重算；helper明确parent-exit-only，不证明完整detached/恶意后代containment；未测同进程FD前后基线。组件成功不关闭完整叶子/P1/P2阶段，全部closure标志仍false；历史失败/未运行/20of21及所有capture失败保留。

No worker build/native test/Git/network/production edit occurred. All saved review outputs are new files under this exclusive review directory.
worker未构建、原生测试、Git、网络或生产修改；审查输出均为独占目录新文件。