param(
    [Parameter(Mandatory)][string] $Nonce,
    [Parameter(Mandatory)][string] $DriverDll,
    [Parameter(Mandatory)][string] $CliDll,
    [Parameter(Mandatory)][string] $ExpectedCliSha256,
    [Parameter(Mandatory)][string] $ExpectedDriverSha256
)
$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSVersion.Major -lt 7) { throw 'PowerShell 7 required' }
if ((Get-Process -Id $PID).Path -ne 'C:\Program Files\PowerShell\7\pwsh.exe') { throw 'Fixed PowerShell executable required' }
$guidValue = [guid]::Empty
if (-not [guid]::TryParseExact($Nonce, 'N', [ref]$guidValue)) { throw 'Exact GUID nonce required' }
if ($ExpectedDriverSha256 -notmatch '^[0-9A-F]{64}$') { throw 'Pinned driver SHA256 required' }
$artifactRoot = 'D:\GitHub\RustSharp\artifacts\p2-supervision\formatter-cli-driver-v11'
$borrow = 'D:\GitHub\RustSharp\artifacts\p2-supervision\formatter-private-console-port-v1\Launcher.dll'
$borrowHash = '509EE571F815F6E0428E61CCEB6C21B5F3642537DFB3F11FCA97A063AFE0DAE9'
if ((Get-FileHash -LiteralPath $borrow -Algorithm SHA256).Hash -ne $borrowHash) { throw 'Borrowed immutable bridge SHA mismatch' }
$assembly = [Reflection.Assembly]::LoadFrom($borrow)
if ($assembly.ManifestModule.ModuleVersionId -ne [guid]'8e90d6af-59a4-4b5d-875f-937f9a15744b') { throw 'Borrowed MVID mismatch' }
$driverAbsolute = [IO.Path]::GetFullPath($DriverDll)
if (-not $driverAbsolute.StartsWith($artifactRoot + '\', [StringComparison]::OrdinalIgnoreCase) -or $driverAbsolute -ne $DriverDll) { throw 'Driver must be an exact absolute descendant of artifact root' }
if ((Get-FileHash -LiteralPath $driverAbsolute -Algorithm SHA256).Hash -ne $ExpectedDriverSha256) { throw 'Driver SHA mismatch' }
$dotnet = 'C:\Program Files\dotnet\dotnet.exe'
if (-not (Test-Path -LiteralPath $dotnet -PathType Leaf)) { throw 'Known dotnet path absent; no tool scan' }
$pdbAbsolute = [IO.Path]::ChangeExtension($driverAbsolute, '.pdb')
if (-not (Test-Path -LiteralPath $pdbAbsolute -PathType Leaf)) { throw 'Exact driver PDB absent' }
$pdbHash = (Get-FileHash -LiteralPath $pdbAbsolute -Algorithm SHA256).Hash
$driverMvid = [Reflection.Assembly]::LoadFile($driverAbsolute).ManifestModule.ModuleVersionId.ToString('D')
$cancellation = [Threading.CancellationTokenSource]::new([TimeSpan]::FromSeconds(30))
$token = $cancellation.Token
$job = $null
$child = $null
$runRoot = $null
$receipt = [ordered]@{ taskId='P2-08.02.CTRL-v2'; version=2; state='FAIL'; nonce=$Nonce; nativeCaseDenominator=1; cliPath=$CliDll; cliSha256=$ExpectedCliSha256; driverSha256=$ExpectedDriverSha256; pdbSha256=$pdbHash; driverMvid=$driverMvid; exactAbsoluteDriver=$driverAbsolute; exactAbsolutePdb=$pdbAbsolute; borrowedSha256=$borrowHash; cliLaunched=$false; cliNativePendingProven=$false; cliNativeCancellationProven=$false; errors=[Collections.Generic.List[string]]::new(); cleanupErrors=[Collections.Generic.List[string]]::new() }
function Convert-Identity($value) {
    [ordered]@{ pid=[uint32]$value.Pid; nativeBirthFileTime=$value.CreationFileTime.ToString([Globalization.CultureInfo]::InvariantCulture); parentPid=[uint32]$value.ParentPid; fullCommand=$value.CommandLine }
}
function Write-NewJson([string]$path, $value) {
    $stream = [IO.FileStream]::new($path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::Read)
    try {
        $bytes = [Text.UTF8Encoding]::new($false).GetBytes(($value | ConvertTo-Json -Depth 20))
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush($true)
    } finally { $stream.Dispose() }
}
function Convert-TypedIdentity($value) {
    [ordered]@{
        runtimeType = $value.GetType().AssemblyQualifiedName
        psTypeNames = @($value.PSObject.TypeNames)
        identity = Convert-Identity $value
    }
}
function Write-AtomicNewJson([string]$path, $value) {
    $temporary = $path + '.' + $Nonce + '.tmp'
    Write-NewJson $temporary $value
    [IO.File]::Move($temporary,$path,$false)
}
function Save-OuterFailureSnapshot($snapshot, [string]$reason) {
    if ($null -eq $runRoot) { return }
    try {
        $knownSet = @()
        if ($null -ne $observed) { $knownSet = @($observed.Values | ForEach-Object { $token.ThrowIfCancellationRequested(); Convert-TypedIdentity $_ }) }
        $members = @()
        if ($null -ne $snapshot) { $members = @($snapshot.Members | ForEach-Object { Convert-TypedIdentity $_ }) }
        $elapsed = $null
        if ($null -ne $watch) { $elapsed = $watch.ElapsedMilliseconds }
        $journal = [ordered]@{
            taskId='P2-08.02.outer-snapshot-journal-v10'; state='SNAPSHOT_FAILURE_UNKNOWN'; reason=$reason
            nonce=$Nonce; capturedAtUtc=[DateTimeOffset]::UtcNow.ToString('o'); check=$check; elapsedMilliseconds=$elapsed
            snapshot=$snapshot; typedMembers=$members; knownSet=$knownSet
            controller=[ordered]@{ identity=$receipt.host; parentChain=$receipt.hostParentChain; provenance='Original prelaunch controller capture' }
            childIdentity=$receipt.child; childCurrentReceipt=$null
        }
        if ($null -ne $child) { $journal.childCurrentReceipt=$child.Receipt }
        $index=[int]$receipt.snapshotJournalCount
        $receipt.snapshotJournalCount=$index+1
        $path=Join-Path $runRoot ('outer-failure-snapshot-'+$index.ToString('D2')+'.json')
        Write-AtomicNewJson $path $journal
        $receipt.lastFailureSnapshotPath=$path
        $receipt.lastFailureSnapshotSha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
    } catch { $receipt.errors.Add('outer failure snapshot journal: '+$_.Exception.ToString()) }
}
try {
    $null = [FormatterPrivateConsoleFixture.ProcessAudit]::VerifyRoot($artifactRoot, $token)
    $null = [FormatterPrivateConsoleFixture.ProcessAudit]::VerifyRoot([IO.Path]::GetDirectoryName($driverAbsolute), $token)
    $hostIdentity = [FormatterPrivateConsoleFixture.ProcessAudit]::Read([uint32]$PID)
    $receipt.host = Convert-Identity $hostIdentity
    $receipt.hostParentChain = [FormatterPrivateConsoleFixture.ProcessAudit]::Capture([uint32]$PID, $token)
    $caseRoot = 'D:\GitHub\RustSharp\artifacts\p2-supervision\formatter-cli-driver-v1'
    $runtimeRoot = Join-Path $caseRoot 'runtime'
    if (-not (Test-Path -LiteralPath $runtimeRoot)) { $null = [IO.Directory]::CreateDirectory($runtimeRoot) }
    $null = [FormatterPrivateConsoleFixture.ProcessAudit]::VerifyRoot($runtimeRoot, $token)
    $runRoot = Join-Path $runtimeRoot $Nonce
    if (Test-Path -LiteralPath $runRoot) { throw 'Refuse reuse or overwrite of existing nonce directory' }
    $null = [IO.Directory]::CreateDirectory($runRoot)
    $null = [FormatterPrivateConsoleFixture.ProcessAudit]::VerifyRoot($runRoot, $token)
    Write-NewJson (Join-Path $runRoot 'host-lease.json') ([ordered]@{ nonce=$Nonce; host=(Convert-Identity $hostIdentity); root=$runRoot; cliPath=$CliDll; cliSha256=$ExpectedCliSha256; driverSha256=$ExpectedDriverSha256; pdbSha256=$pdbHash; driverMvid=$driverMvid; exactAbsoluteDriver=$driverAbsolute; exactAbsolutePdb=$pdbAbsolute; borrowedSha256=$borrowHash })
    $hostLeaseHash = (Get-FileHash -LiteralPath (Join-Path $runRoot 'host-lease.json') -Algorithm SHA256).Hash
    $job = [FormatterPrivateConsoleFixture.JobLease]::new()
    [FormatterPrivateConsoleFixture.JobLease]::RequireExact($job.Inspect(), [FormatterPrivateConsoleFixture.ProcessIdentity[]]@(), 0)
    $arguments = [string[]]@($driverAbsolute, '--child', $Nonce, $hostLeaseHash)
    $child = [FormatterPrivateConsoleFixture.OwnedSuspendedProcess]::Start($dotnet, $arguments, $runRoot, $true, $job, $null)
    [FormatterPrivateConsoleFixture.JobLease]::RequireExact($job.Inspect(), [FormatterPrivateConsoleFixture.ProcessIdentity[]]@($child.Identity), 1)
    $child.Recheck()
    $receipt.child = Convert-Identity $child.Identity
    Write-NewJson (Join-Path $runRoot 'launch.json') ([ordered]@{ host=(Convert-Identity $hostIdentity); child=(Convert-Identity $child.Identity); suspended=$true; exactJobMembership=$child.Receipt.MembershipVerified; driverSha256=$ExpectedDriverSha256 })
    $receipt.launchSha256 = (Get-FileHash -LiteralPath (Join-Path $runRoot 'launch.json') -Algorithm SHA256).Hash
    $child.Resume()
    Write-Progress -Activity 'Single owned ordinary-file native foundation' -Status 'One child resumed; bounded 15 second native wait'
    $observed = [Collections.Generic.Dictionary[uint32,FormatterPrivateConsoleFixture.ProcessIdentity]]::new()
    $observed.Add($child.Identity.Pid,$child.Identity)
    $receipt.outerObserved = [Collections.Generic.List[object]]::new()
    $receipt.outerObserved.Add((Convert-Identity $child.Identity))
    $receipt.outerSnapshots = [Collections.Generic.List[object]]::new()
    $watch = [Diagnostics.Stopwatch]::StartNew()
    $exited = $false
    for ($check=0; $check -lt 600 -and $watch.ElapsedMilliseconds -lt 15000; $check++) {
        $token.ThrowIfCancellationRequested()
        $snapshot = $job.Inspect()
        if (-not $snapshot.Coherent -or $snapshot.Overflow -or $snapshot.Failures.Count -ne 0 -or $snapshot.Total -gt 3 -or $snapshot.Members.Count -gt 3) {
            Save-OuterFailureSnapshot $snapshot 'Exact outer-job snapshot failed or cumulative cap3 exceeded'
            $exactTerminatingDriver = (
                $snapshot.Coherent -and -not $snapshot.Overflow -and $snapshot.Total -eq 3 -and
                $snapshot.Active -eq 1 -and $snapshot.Assigned -eq 1 -and $snapshot.Listed -eq 1 -and
                $snapshot.Members.Count -eq 0 -and $snapshot.Failures.Count -eq 1 -and
                $snapshot.Failures[0].Pid -eq $child.Identity.Pid -and
                [string]::Equals($snapshot.Failures[0].Error,'NT command query status=0xC000010A',[StringComparison]::Ordinal) -and
                $observed.Count -eq 3 -and $observed.ContainsKey($child.Identity.Pid) -and
                $observed[$child.Identity.Pid].Equals($child.Identity) -and
                $child.Receipt.IdentityVerified -eq $true -and $child.Receipt.Assigned -eq $true -and
                $child.Receipt.MembershipVerified -eq $true -and $child.Receipt.Resumed -eq $true -and
                $null -eq $child.Receipt.TerminationReturn -and $child.Receipt.ProcessHandleClosed -ne $true
            )
            $completeKnown = 0
            foreach ($knownIdentity in $observed.Values) {
                $token.ThrowIfCancellationRequested()
                if ($knownIdentity.Pid -ne 0 -and $knownIdentity.CreationFileTime -gt 0 -and $knownIdentity.ParentPid -ne 0 -and -not [string]::IsNullOrEmpty($knownIdentity.CommandLine)) { $completeKnown++ }
            }
            if ($exactTerminatingDriver -and $completeKnown -eq 3 -and $watch.ElapsedMilliseconds -lt 14000) {
                $receipt.exitRaceOriginalSnapshot = $snapshot
                $receipt.exitRaceRetainedIdentity = Convert-TypedIdentity $child.Identity
                $receipt.exitRaceWaitMaximumSeconds = 1
                if (-not $child.Wait(1,$token) -or $child.ExitCode -ne 0 -or $null -ne $child.Receipt.TerminationReturn) { throw 'Exact retained driver did not naturally exit zero within one second' }
                $afterExit = $job.Inspect()
                [FormatterPrivateConsoleFixture.JobLease]::RequireExact($afterExit,[FormatterPrivateConsoleFixture.ProcessIdentity[]]@(),3)
                $receipt.exitRaceCleanEmptySnapshot = $afterExit
                $receipt.exitRaceBoundedRetainedNativeExit = $true
                Write-AtomicNewJson (Join-Path $runRoot 'exact-driver-exit-race.json') ([ordered]@{ originalSnapshot=$snapshot; retainedDriver=(Convert-TypedIdentity $child.Identity); knownSet=@($observed.Values | ForEach-Object { Convert-TypedIdentity $_ }); waitMaximumSeconds=1; nativeExitCode=$child.ExitCode; terminationReturn=$child.Receipt.TerminationReturn; finalSnapshot=$afterExit })
                $snapshot=$afterExit
                $exited=$true
                break
            }
            throw 'Exact outer-job snapshot failed or cumulative cap3 exceeded'
        }
        $receipt.outerSnapshots.Add([ordered]@{ check=$check; elapsed=$watch.ElapsedMilliseconds; total=$snapshot.Total; active=$snapshot.Active; listed=$snapshot.Listed; assigned=$snapshot.Assigned })
        for ($memberIndex=0; $memberIndex -lt $snapshot.Members.Count -and $memberIndex -lt 3 -and $watch.ElapsedMilliseconds -lt 15000; $memberIndex++) {
            $member=$snapshot.Members[$memberIndex]
            if ($observed.ContainsKey($member.Pid)) {
                if (-not $observed[$member.Pid].Equals($member)) {
                    Save-OuterFailureSnapshot $snapshot 'Outer identity comparison failed'
                    try {
                        $known = $observed[$member.Pid]
                        $snapshotMembers = @($snapshot.Members | ForEach-Object { Convert-TypedIdentity $_ })
                        $mismatch = [ordered]@{
                            taskId = 'P2-08.02.conhost-identity-journal-v9'
                            state = 'IDENTITY_MISMATCH_UNKNOWN'
                            nonce = $Nonce
                            capturedAtUtc = [DateTimeOffset]::UtcNow.ToString('o')
                            check = $check
                            elapsedMilliseconds = $watch.ElapsedMilliseconds
                            memberIndex = $memberIndex
                            known = Convert-TypedIdentity $known
                            observed = Convert-TypedIdentity $member
                            equalsResult = $false
                            referenceEquals = [object]::ReferenceEquals($known,$member)
                            snapshot = [ordered]@{
                                coherent = $snapshot.Coherent
                                overflow = $snapshot.Overflow
                                failures = @($snapshot.Failures)
                                total = $snapshot.Total
                                active = $snapshot.Active
                                listed = $snapshot.Listed
                                assigned = $snapshot.Assigned
                                members = $snapshotMembers
                            }
                            controller = [ordered]@{
                                identity = Convert-TypedIdentity $hostIdentity
                                parentChain = $receipt.hostParentChain
                                provenance = 'Original controller identity and parent chain captured before child creation'
                            }
                            child = [ordered]@{
                                identity = Convert-TypedIdentity $child.Identity
                                currentReceipt = $child.Receipt
                            }
                        }
                        $journalPath = Join-Path $runRoot 'identity-mismatch.json'
                        Write-AtomicNewJson $journalPath $mismatch
                        $receipt.identityMismatchPath = $journalPath
                        $receipt.identityMismatchSha256 = (Get-FileHash -LiteralPath $journalPath -Algorithm SHA256).Hash
                    } catch { $receipt.errors.Add('identity mismatch journal: ' + $_.Exception.ToString()) }
                    throw 'Outer PID reused or native birth/fullcmd/parent changed'
                }
            } else { $observed.Add($member.Pid,$member); $receipt.outerObserved.Add((Convert-Identity $member)) }
        }
        if ($observed.Count -gt 3) { Save-OuterFailureSnapshot $snapshot 'Outer unique native identity cap3 exceeded'; throw 'Outer unique native identity cap3 exceeded' }
        if ($child.HasExited()) { $exited=$true; break }
        if ($check % 40 -eq 0) { Write-Progress -Activity 'Exact outer-job identity collection' -Status ('Sample '+$check+'; unique '+$observed.Count) }
        Start-Sleep -Milliseconds 25
    }
    Write-Progress -Activity 'Exact outer-job identity collection' -Completed
    # Every successfully observed identity is already recorded before later guards.
    if (-not $exited) { throw 'Outer observation600/15s bound; finally must reap exact private job' }
    if (-not $child.Wait(1,$token)) { throw 'Signaled child exact native exit-code read failed' }
    $receipt.actualChildExitCode = $child.ExitCode
    $childReportPath = Join-Path $runRoot 'child-report.json'
    if (-not (Test-Path -LiteralPath $childReportPath -PathType Leaf)) { throw 'Child report missing' }
    $receipt.childReportSha256 = (Get-FileHash -LiteralPath $childReportPath -Algorithm SHA256).Hash
    $receipt.childReport = Get-Content -LiteralPath $childReportPath -Raw | ConvertFrom-Json -DateKind String
    $expectedIdentities = [Collections.Generic.Dictionary[uint32,object]]::new()
    $expectedIdentities.Add($child.Identity.Pid,(Convert-Identity $child.Identity))
    $actualCli=$receipt.childReport.cli
    if ($null -eq $actualCli) { throw 'Actual CLI identity absent' }
    $expectedIdentities.Add([uint32]$actualCli.pid,$actualCli)
    $actualConhost=$receipt.childReport.conhost
    if ($null -ne $actualConhost -and $observed.ContainsKey([uint32]$actualConhost.pid)) { $expectedIdentities.Add([uint32]$actualConhost.pid,$actualConhost) }
    if ($expectedIdentities.Count -ne $observed.Count) { throw 'Observed outer set is not exact driver/actualCLI/observedConhost' }
    foreach ($nativeIdentity in $observed.Values) {
        if (-not $expectedIdentities.ContainsKey($nativeIdentity.Pid)) { throw 'Unowned outer member' }
        $expectedIdentity=$expectedIdentities[$nativeIdentity.Pid]
        if ($nativeIdentity.CreationFileTime.ToString([Globalization.CultureInfo]::InvariantCulture) -ne [string]$expectedIdentity.nativeBirthFileTime -or $nativeIdentity.CommandLine -cne [string]$expectedIdentity.fullCommand -or $nativeIdentity.ParentPid -ne [uint32]$expectedIdentity.parentPid) { throw 'Exact outer identity binding mismatch' }
    }
    $finalOuter=$job.Inspect()
    [FormatterPrivateConsoleFixture.JobLease]::RequireExact($finalOuter,[FormatterPrivateConsoleFixture.ProcessIdentity[]]@(),[uint32]$observed.Count)
    $receipt.outerExactCumulativeIdentityReconciled=$true
    $receipt.outerExactCumulativeTotal=$observed.Count
    if ($child.ExitCode -ne 0 -or $receipt.childReport.state -ne 'CLI_OPEN_SIGNAL_PASS') { throw 'Helper native foundation did not close; all evidence retained' }
    $receipt.state = 'CLI_OPEN_SIGNAL_PASS_PENDING_ROOT_REVIEW'
} catch {
    $originalFailure = $_
    if ($null -ne $job) {
        try { Save-OuterFailureSnapshot ($job.Inspect()) ('Outer catch: '+$originalFailure.Exception.Message) }
        catch { $receipt.errors.Add('outer catch snapshot: '+$_.Exception.ToString()) }
    }
    $receipt.errors.Add($originalFailure.Exception.ToString())
} finally {
    if ($null -ne $runRoot) {
        try { Write-AtomicNewJson (Join-Path $runRoot 'outer-observed-final.json') ([ordered]@{ nonce=$Nonce; observed=$receipt.outerObserved; snapshots=$receipt.outerSnapshots; lastFailureSnapshotPath=$receipt.lastFailureSnapshotPath }) }
        catch { $receipt.cleanupErrors.Add('observed final journal: '+$_.Exception.ToString()) }
    }
    Write-Progress -Activity 'Single owned ordinary-file native foundation' -Completed
    if ($null -ne $child) {
        try { $child.Dispose(); $receipt.launchReceipt = $child.Receipt } catch { $receipt.cleanupErrors.Add('owned child: ' + $_.Exception.ToString()) }
    }
    if ($null -ne $job) {
        try { $receipt.outerJobBeforeReap = $job.Inspect(); if ($receipt.outerJobBeforeReap.Active -ne 0 -or $receipt.outerJobBeforeReap.Assigned -ne 0 -or $receipt.outerJobBeforeReap.Listed -ne 0) { throw "Outer owned process tree not empty before recap" }; if ($receipt.outerJobBeforeReap.Total -lt 2 -or $receipt.outerJobBeforeReap.Total -gt 3) { throw "Outer cumulative driver/CLI/conhost count outside exact documented 2-or-3 topology; root must reconcile identities" } } catch { $receipt.cleanupErrors.Add("outer cumulative snapshot: " + $_.Exception.ToString()) }
        try { $receipt.privateJobCleanup = $job.Reap([Threading.CancellationToken]::None) } catch { $receipt.cleanupErrors.Add('private job recap: ' + $_.Exception.ToString()) }
        finally {
            try { $job.Dispose(); $receipt.privateJobCleanup = $job.Cleanup } catch { $receipt.cleanupErrors.Add('private job close: ' + $_.Exception.ToString()) }
        }
    }
    $receipt.resourceClosure = ($receipt.outerExactCumulativeIdentityReconciled -eq $true -and $null -ne $receipt.privateJobCleanup -and $receipt.privateJobCleanup.AccountingZero -and $receipt.privateJobCleanup.HandleClosed -and $receipt.privateJobCleanup.Errors.Count -eq 0 -and $null -ne $receipt.launchReceipt -and $receipt.launchReceipt.OwnProcessReclaimed -and $receipt.launchReceipt.CleanupErrors.Count -eq 0 -and $receipt.errors.Count -eq 0 -and $receipt.cleanupErrors.Count -eq 0)
    if (-not $receipt.resourceClosure -or $null -eq $receipt.childReport -or $receipt.childReport.state -ne 'CLI_OPEN_SIGNAL_PASS') { $receipt.state = 'FAIL' }
    else { $receipt.state = 'CLI_OPEN_SIGNAL_PASS_PENDING_ROOT_REVIEW' }
    $receipt.cliProof = 'NO_NATIVE_CLI_PROOF'
    if ($null -ne $runRoot) {
        try { Write-NewJson (Join-Path $runRoot 'supervisor-report.json') $receipt } catch { $receipt.cleanupErrors.Add('receipt persistence: ' + $_.Exception.ToString()); $receipt.state = 'FAIL'; $receipt.resourceClosure = $false }
    }
    $cancellation.Dispose()
    $receipt | ConvertTo-Json -Depth 20
}
if ($receipt.errors.Count -ne 0 -or $receipt.cleanupErrors.Count -ne 0 -or $null -eq $receipt.privateJobCleanup -or -not $receipt.privateJobCleanup.AccountingZero -or -not $receipt.privateJobCleanup.HandleClosed -or $receipt.privateJobCleanup.Errors.Count -ne 0 -or $null -eq $receipt.launchReceipt -or -not $receipt.launchReceipt.OwnProcessReclaimed -or $receipt.launchReceipt.CleanupErrors.Count -ne 0) { throw 'Foundation failed or resource cleanup incomplete; no CLI/leaf/phase acceptance' }
