using System.ComponentModel;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text.Json.Nodes;
using FormatterPrivateConsoleFixture;
using Microsoft.Win32.SafeHandles;

namespace FormatterCliDriverV11;

internal static partial class Driver
{
    private const string ArtifactRoot = @"D:\GitHub\RustSharp\artifacts\p2-supervision\formatter-cli-driver-v11";
    private const string CaseRoot = @"D:\GitHub\RustSharp\artifacts\p2-supervision\formatter-cli-driver-v1";
    private const string BorrowHash = "509EE571F815F6E0428E61CCEB6C21B5F3642537DFB3F11FCA97A063AFE0DAE9";
    private static readonly List<object> RetainedOwners = [];
    private static readonly byte[] MicroInput = "fn main() {}\n"u8.ToArray();

    private static int Main(string[] args)
    {
        var report = new JsonObject { ["taskId"] = "P2-08.02.CTRL-v2", ["version"] = 2,
            ["caseDenominator"] = 1, ["cliNativePendingProven"] = false,
            ["cliNativeCancellationProven"] = false, ["cliLaunched"] = false,
            ["state"] = "FAIL", ["errors"] = new JsonArray(), ["cleanupErrors"] = new JsonArray() };
        string? runRoot = null;
        string? source = null;
        FileIdentity? createdIdentity = null;
        SafeFileHandle? file = null;
        OwnedSuspendedProcess? cli = null; JobLease? cliJob = null; bool consoleAllocated = false; ProcessIdentity? consoleHost = null; Process? retainedConhost = null; SafeProcessHandle? retainedConhostHandle = null; SafeWaitHandle? pendingThread = null;
        SafeWaitHandle? completed = null;
        nint statusBlock = 0;
        bool nativePending = false;
        bool completedProven = false;
        bool ownedSource = false;
        var wall = Stopwatch.StartNew();
        using var cancellation = new CancellationTokenSource(TimeSpan.FromSeconds(12));
        ConsoleCancelEventHandler cancelHandler = (_, e) => { e.Cancel = true; cancellation.Cancel(); };
        Console.CancelKeyPress += cancelHandler;
        try
        {
            Need(OperatingSystem.IsWindows() && IntPtr.Size == 8, "Windows x64 required");
            Need(args.Length == 3 && args[0] == "--child" && Guid.TryParseExact(args[1], "N", out _), "Exact child/nonce/launch-hash arguments required");
            string borrowed = Path.Combine(AppContext.BaseDirectory, "Launcher.dll");
            Need(Hash(borrowed) == BorrowHash && typeof(ProcessAudit).Assembly.ManifestModule.ModuleVersionId == Guid.Parse("8e90d6af-59a4-4b5d-875f-937f9a15744b"), "Frozen borrowed native bridge binding");
            ProcessAudit.VerifyRoot(ArtifactRoot, cancellation.Token);
            runRoot = Path.Combine(CaseRoot, "runtime", args[1]);
            ProcessAudit.VerifyRoot(runRoot, cancellation.Token);
            string launchPath = Path.Combine(runRoot, "launch.json");
            string hostLeasePath = Path.Combine(runRoot, "host-lease.json");
            Need(Hash(hostLeasePath) == args[2], "Immutable pre-launch host lease hash (no command/hash cycle)");
            JsonObject hostLease = JsonNode.Parse(File.ReadAllText(hostLeasePath))?.AsObject() ?? throw new InvalidDataException("host lease JSON");
            string actualDriver = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "CliOpenDriver.dll"));
            string actualPdb = Path.ChangeExtension(actualDriver, ".pdb");
            Need(actualDriver == hostLease["exactAbsoluteDriver"]!.GetValue<string>() && actualPdb == hostLease["exactAbsolutePdb"]!.GetValue<string>() && actualDriver.StartsWith(ArtifactRoot + Path.DirectorySeparatorChar, StringComparison.Ordinal), "Actual base directory driver/PDB absolute lease binding");
            ProcessAudit.VerifyRoot(AppContext.BaseDirectory, cancellation.Token);
            string actualDriverHash = Hash(actualDriver), actualPdbHash = Hash(actualPdb);
            Need(actualDriverHash == hostLease["driverSha256"]!.GetValue<string>() && actualPdbHash == hostLease["pdbSha256"]!.GetValue<string>() && typeof(Driver).Assembly.ManifestModule.ModuleVersionId.ToString("D") == hostLease["driverMvid"]!.GetValue<string>(), "Independent actual driver/PDB SHA and loaded MVID binding");
            report["actualDriver"] = actualDriver; report["actualPdb"] = actualPdb; report["actualDriverSha256"] = actualDriverHash; report["actualPdbSha256"] = actualPdbHash; report["actualDriverMvid"] = typeof(Driver).Assembly.ManifestModule.ModuleVersionId.ToString("D");
            JsonObject launch = JsonNode.Parse(File.ReadAllText(launchPath))?.AsObject() ?? throw new InvalidDataException("launch JSON");
            var self = ProcessAudit.Read(checked((uint)Environment.ProcessId));
            var host = ReadIdentity(launch["host"]?.AsObject() ?? throw new InvalidDataException("host absent"));
            Need(host == ReadIdentity(hostLease["host"]!.AsObject()) && hostLease["nonce"]!.GetValue<string>() == args[1], "Bound pre-launch host lease/nonce");
            var expected = ReadIdentity(launch["child"]?.AsObject() ?? throw new InvalidDataException("child absent"));
            Need(self == expected && self.ParentPid == host.Pid && ProcessAudit.Read(host.Pid) == host, "Actual PID/native birth/full command/direct parent binding");
            var chain = ProcessAudit.ToBoundary(self.Pid, host, cancellation.Token);
            Need(chain.BoundaryVerified && chain.Nodes.Count == 2 && chain.Nodes[0] == self && chain.Nodes[1] == host && host.CreationFileTime <= self.CreationFileTime, "Exact native parent boundary and birth chronology");
            report["owner"] = Identity(self); report["host"] = Identity(host);
            report["launchSha256"] = Hash(launchPath);
            report["parentBoundaryVerified"] = chain.BoundaryVerified;
            report["systemAncestorsComplete"] = chain.SystemAncestorsComplete;
            source = Path.Combine(runRoot, "source.rs");
            using (var create = new FileStream(source, FileMode.CreateNew, FileAccess.Write, FileShare.Read, 4096, FileOptions.WriteThrough))
            { ownedSource = true; create.Write(MicroInput); create.Flush(flushToDisk: true); }
            createdIdentity = ReadFileIdentity(source);
            Need(createdIdentity.FinalPath == source && createdIdentity.NativeBirth > 0 && createdIdentity.Volume != 0 && (createdIdentity.IdLow != 0 || createdIdentity.IdHigh != 0) && (createdIdentity.Attributes & 0x410) == 0 && Hash(source) == Convert.ToHexString(SHA256.HashData(MicroInput)), "Exclusive ordinary-file path/type/native identity/content");
            report["source"] = createdIdentity.Json(); report["sourceSha256"] = Hash(source);
            var lease = new JsonObject { ["nonce"] = args[1], ["taskId"] = "P2-08.02.CTRL-v2", ["owner"] = Identity(self), ["file"] = createdIdentity.Json(), ["sha256"] = Hash(source), ["hostLeaseSha256"] = args[2], ["sourceDisposition"] = "DELIVERED_ARTIFACT_RETAINED" };
            WriteNew(Path.Combine(runRoot, "source-lease.json"), lease);
            report["sourceLeaseSha256"] = Hash(Path.Combine(runRoot, "source-lease.json"));
            cancellation.Token.ThrowIfCancellationRequested();
            Need(wall.Elapsed.TotalSeconds < 12 && ProcessAudit.Read(self.Pid) == self && ReadFileIdentity(source) == createdIdentity, "Pre-native ownership recheck");
            file = File.OpenHandle(source, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, FileOptions.Asynchronous);
            Need(ReadFileIdentity(file) == createdIdentity, "Actual oplock handle native file ID/birth/path recheck");
            completed = CreateEventW(0, 1, 0, 0);
            Need(!completed.IsInvalid, "Private event creation Win32=" + Marshal.GetLastPInvokeError());
            statusBlock = Marshal.AllocHGlobal(16); Marshal.WriteInt64(statusBlock, 0, 0); Marshal.WriteInt64(statusBlock, 8, 0);
            // FSCTL_REQUEST_BATCH_OPLOCK: read-only holder is compatible with production FILE_SHARE_READ.
            int request = NtFsControlFile(file, completed, 0, 0, statusBlock, 0x00090008, 0, 0, 0, 0);
            nativePending = request == 0x103;
            report["nativeRequestStatus"] = request; report["helperOplockPending"] = nativePending;
            report["holderAccess"] = "Read"; report["holderShare"] = "ReadWriteDelete"; report["holdKind"] = "BATCH";
            Need(nativePending, "UNKNOWN: compatible read-only batch hold was not granted");
            string cliPath = hostLease["cliPath"]!.GetValue<string>();
            string cliHash = hostLease["cliSha256"]!.GetValue<string>();
            Need(cliPath == Path.Combine(CaseRoot, "cli-bin", "rsc.dll") && Hash(cliPath) == cliHash, "Exact production candidate CLI binding");
            Need(AllocConsole() != 0, "Driver must start detached and allocate its own private console");
            consoleAllocated = true;
            nint window = GetConsoleWindow();
            int windowLastError = Marshal.GetLastPInvokeError();
            int visibleBefore = window == 0 ? 0 : IsWindowVisible(window);
            int visibleBeforeError = Marshal.GetLastPInvokeError();
            int hidePrevious = window == 0 ? 0 : ShowWindow(window, 0);
            int hideLastError = Marshal.GetLastPInvokeError();
            int visibleAfter = window == 0 ? 0 : IsWindowVisible(window);
            int visibleAfterError = Marshal.GetLastPInvokeError();
            uint windowThread = GetWindowThreadProcessId(window, out uint conhostPid);
            int windowOwnerError = Marshal.GetLastPInvokeError();
            nint consoleBuffer = Marshal.AllocHGlobal(12);
            uint consoleCount; int consoleError; var consoleMembers = new JsonArray();
            try
            {
                Marshal.WriteInt32(consoleBuffer,0,0); Marshal.WriteInt32(consoleBuffer,4,0); Marshal.WriteInt32(consoleBuffer,8,0);
                consoleCount = GetConsoleProcessList(consoleBuffer,3); consoleError = Marshal.GetLastPInvokeError();
                var queryClock = Stopwatch.StartNew();
                for(int slot=0;slot<3 && slot<consoleCount && queryClock.ElapsedMilliseconds<1000;slot++)
                {
                    cancellation.Token.ThrowIfCancellationRequested();
                    consoleMembers.Add((JsonNode?)JsonValue.Create(unchecked((uint)Marshal.ReadInt32(consoleBuffer,slot*4))));
                }
            }
            finally { Marshal.FreeHGlobal(consoleBuffer); }
            string driverImage = ProcessAudit.ImagePath(self);
            var consoleJournal = new JsonObject
            {
                ["taskId"]="P2-08.02.conhost-diagnosis-v5",["nonce"]=args[1],["cliLaunched"]=false,
                ["driver"]=Identity(self),["driverImage"]=driverImage,["driverImageSha256"]=Hash(driverImage),
                ["windowHandleHex"]=window.ToInt64().ToString("X",CultureInfo.InvariantCulture),
                ["getConsoleWindowLastError"]=windowLastError,["visibleBefore"]=visibleBefore,
                ["visibleBeforeLastError"]=visibleBeforeError,["showWindowPreviousState"]=hidePrevious,
                ["showWindowLastError"]=hideLastError,["visibleAfter"]=visibleAfter,["visibleAfterLastError"]=visibleAfterError,
                ["getWindowThreadProcessIdReturn"]=windowThread,["windowOwnerPid"]=conhostPid,
                ["getWindowThreadProcessIdLastError"]=windowOwnerError,["consoleProcessListReturn"]=consoleCount,
                ["consoleProcessListLastError"]=consoleError,["consoleMembers"]=consoleMembers,
                ["lastErrorInterpretation"]="Only API-documented failure values establish meaningful errors; successful-call residuals are raw observations."
            };
            string journalPath = Path.Combine(runRoot,"console-before-guard.json");
            WriteAtomicNew(journalPath,consoleJournal);
            report["consoleBeforeGuardSha256"] = Hash(journalPath);
            Need(window != 0, "Own console window absent");
            Need(visibleAfter == 0, "Own console did not hide");
            Need(consoleCount == 1 && consoleMembers.Count == 1 && consoleMembers[0]!.GetValue<uint>() == self.Pid, "Exact private pre-CLI driver console membership");
            report["windowOwnerIsDriver"] = conhostPid == self.Pid;
            ProcessIdentity discoveredHost = DiscoverOwnedConhost(self, report, cancellation.Token);
            conhostPid = discoveredHost.Pid;
            Need(conhostPid != 0 && conhostPid != self.Pid, "Independent native conhost must be a verified owned-job child; window ownership is separate");
            Need(ProcessAudit.Read(conhostPid) == discoveredHost, "Discovery native identity before retained-handle acquisition");
            consoleHost = discoveredHost;
            retainedConhost = Process.GetProcessById(checked((int)conhostPid));
            retainedConhostHandle = retainedConhost.SafeHandle;
            Need(ProcessAudit.Read(conhostPid) == discoveredHost, "Discovery native identity after retained-handle acquisition");
            Need(GetProcessTimes(retainedConhostHandle, out long conhostBirth, out long conhostExit, out _, out _) != 0 && conhostBirth == consoleHost.CreationFileTime && conhostExit == 0, "Retained exact native conhost identity");
            string conhostImage = ProcessAudit.ImagePath(consoleHost);
            Need(conhostImage.Equals(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "conhost.exe"), StringComparison.OrdinalIgnoreCase), "Exact system conhost image required; alternative hosts stay unknown");
            report["conhostImage"] = conhostImage; report["conhostImageSha256"] = Hash(conhostImage);
            report["conhost"] = Identity(consoleHost);
            cliJob = new JobLease();
            Environment.SetEnvironmentVariable("RUSTSHARP_FMT_OPEN_PROBE_LEASE", Path.Combine(runRoot, "cli-probe-lease.json"));
            using (var leaseOutput = new FileStream(Path.Combine(runRoot, "cli-probe-lease.json"), FileMode.CreateNew, FileAccess.Write, FileShare.Read))
            using (var leaseWriter = new StreamWriter(leaseOutput))
                leaseWriter.Write(new JsonObject { ["nonce"] = args[1], ["source"] = source, ["cliPath"] = cliPath, ["cliSha256"] = cliHash, ["cliPdbSha256"] = Hash(Path.ChangeExtension(cliPath, ".pdb")), ["cliMvid"] = ReadFileMvid(cliPath), ["driverPid"] = self.Pid, ["driverBirth"] = self.CreationFileTime.ToString(CultureInfo.InvariantCulture) }.ToJsonString());
            cli = OwnedSuspendedProcess.Start(@"C:\Program Files\dotnet\dotnet.exe", [cliPath, "fmt", source], runRoot, false, cliJob);
            report["cli"] = Identity(cli.Identity); report["cliLaunched"] = true;
            JobLease.RequireExact(cliJob.Inspect(), [cli.Identity], 1);
            cli.Resume();
            // Must ignore only after child creation, so the CLI never inherits CTRL_C ignore.
            Need(SetConsoleCtrlHandler(0, 1) != 0, "Own driver CTRL_C ignore");
            string readyPath = Path.Combine(runRoot, "open-ready.json");
            var readyClock = Stopwatch.StartNew();
            for (int check = 0; check < 80 && readyClock.ElapsedMilliseconds < 2000 && !File.Exists(readyPath); check++)
            { cancellation.Token.ThrowIfCancellationRequested(); if (check % 20 == 0) Console.Error.WriteLine("production open-ready witness " + check); Thread.Sleep(25); }
            Need(File.Exists(readyPath), "NOT_READY: reviewed production probe required; no guessed thread/token evidence");
            JsonObject ready = JsonNode.Parse(File.ReadAllText(readyPath))!.AsObject();
            Need(ready["nonce"]!.GetValue<string>() == args[1] && ready["pid"]!.GetValue<uint>() == cli.Identity.Pid && ready["processBirth"]!.GetValue<string>() == cli.Identity.CreationFileTime.ToString(CultureInfo.InvariantCulture) && ready["source"]!.GetValue<string>() == source && ready["tokenRegistered"]!.GetValue<bool>() && ready["handlerRegistered"]!.GetValue<bool>(), "Actual production registered-handler/process/thread lease");
            uint tid = ready["threadId"]!.GetValue<uint>(); long threadBirth = long.Parse(ready["threadBirth"]!.GetValue<string>(), CultureInfo.InvariantCulture);
            pendingThread = OpenThread(0x00100040, 0, tid);
            Need(!pendingThread.IsInvalid && GetProcessIdOfThread(pendingThread) == cli.Identity.Pid && GetThreadTimes(pendingThread, out long nativeBirth, out _, out _, out _) != 0 && nativeBirth == threadBirth, "Actual production native thread identity");
            var pendingClock = Stopwatch.StartNew(); bool pendingCreate = false;
            for (int check = 0; check < 40 && pendingClock.ElapsedMilliseconds < 1000; check++)
            {
                cancellation.Token.ThrowIfCancellationRequested();
                Need(GetThreadIOPendingFlag(pendingThread, out int pending) != 0, "Actual thread IO query");
                pendingCreate = pending != 0 && WaitForSingleObject(completed, 0) == 0;
                if (pendingCreate) break;
                if (check % 10 == 0) Console.Error.WriteLine("production actual native IO pending " + check);
                Thread.Sleep(25);
            }
            Need(pendingCreate, "Actual production ordinary-file open pending + held break required");
            completedProven = true;
            cli.Recheck(); Need(!cli.HasExited(), "Production CLI live before real signal");
            nint members = Marshal.AllocHGlobal(12);
            try { Need(GetConsoleProcessList(members, 3) == 2 && new[] { unchecked((uint)Marshal.ReadInt32(members)), unchecked((uint)Marshal.ReadInt32(members, 4)) }.Order().SequenceEqual(new[] { self.Pid, cli.Identity.Pid }.Order()), "Exact self-created private driver+CLI console"); }
            finally { Marshal.FreeHGlobal(members); }
            int signal = GenerateConsoleCtrlEvent(0, 0); report["ctrlSignalReturn"] = signal; report["ctrlSignalError"] = Marshal.GetLastPInvokeError();
            Need(signal != 0, "Real directed private-console CTRL_C_EVENT");
            report["ctrlSignalSource"] = "GenerateConsoleCtrlEvent(CTRL_C_EVENT,0) on exact owned console";
            Need(cli.Wait(5, cancellation.Token) && cli.ExitCode == 130, "Actual production natural exit130 before hold release");
            Need(WaitForThread(pendingThread, 0) == 0, "Actual production open thread exited");
            string finishPath = Path.Combine(runRoot, "open-finished.json");
            Need(File.Exists(finishPath), "Raw production995/Join/owner receipt required; natural130 is insufficient");
            JsonObject finish = JsonNode.Parse(File.ReadAllText(finishPath))!.AsObject();
            Need(finish["nonce"]!.GetValue<string>() == args[1] && finish["pid"]!.GetValue<uint>() == cli.Identity.Pid && finish["processBirth"]!.GetValue<string>() == cli.Identity.CreationFileTime.ToString(CultureInfo.InvariantCulture) && finish["processBirth"]!.GetValue<string>() == ready["processBirth"]!.GetValue<string>() && finish["source"]!.GetValue<string>() == source && finish["source"]!.GetValue<string>() == ready["source"]!.GetValue<string>() && finish["threadId"]!.GetValue<uint>() == tid && finish["threadBirth"]!.GetValue<string>() == threadBirth.ToString(CultureInfo.InvariantCulture) && finish["threadBirth"]!.GetValue<string>() == ready["threadBirth"]!.GetValue<string>() && finish["createError"]!.GetValue<int>() == 995 && finish["nativeExitAndJoin"]!.GetValue<bool>() && finish["threadHandleClosed"]!.GetValue<bool>(), "Actual production identity995/exitJoin/handle closure");
            report["productionFinish"] = finish.DeepClone();
            report["cliNativePendingProven"] = true; report["cliNativeCancellationProven"] = true;
            report["casePassedBeforeCleanup"] = true;
        }
        catch (Exception error) { ((JsonArray)report["errors"]!).Add((JsonNode?)JsonValue.Create((string)(error.ToString()))); }
        finally
        {
            Console.CancelKeyPress -= cancelHandler;
            if (cli is not null)
            {
                try { cli.Dispose(); report["cliActualExit"] = cli.Receipt.ActualExitCode; report["cliProcessReclaimed"] = cli.Receipt.OwnProcessReclaimed; Need(cli.Receipt.OwnProcessReclaimed && cli.Receipt.CleanupErrors.Count == 0, "Actual CLI handles and identity reclaimed"); }
                catch (Exception error) { ((JsonArray)report["cleanupErrors"]!).Add((JsonNode?)JsonValue.Create((string)("CLI: " + error))); }
            }
            if (cliJob is not null)
            {
                try
                {
                    var beforeReap = cliJob.Inspect();
                    report["cliJobCumulativeTotal"] = beforeReap.Total;
                    if (report["casePassedBeforeCleanup"]?.GetValue<bool>() == true) JobLease.RequireExact(beforeReap, [], 1);
                    var recap = cliJob.Reap(CancellationToken.None);
                    report["cliJobZero"] = recap.AccountingZero;
                    Need(recap.AccountingZero && recap.Errors.Count == 0, "Complete owned CLI private job recap");
                }
                catch (Exception error) { ((JsonArray)report["cleanupErrors"]!).Add((JsonNode?)JsonValue.Create((string)("CLI job: " + error))); }
                finally { try { cliJob.Dispose(); report["cliJobClosed"] = cliJob.Cleanup.HandleClosed; Need(cliJob.Cleanup.HandleClosed is true, "Private CLI job handle close"); } catch (Exception error) { ((JsonArray)report["cleanupErrors"]!).Add((JsonNode?)JsonValue.Create((string)("CLI job close: " + error))); } }
            }
            if (consoleAllocated)
            {
                try
                {
                    Need(FreeConsole() != 0, "Own console detach");
                    if (consoleHost is not null)
                    {
                        Need(retainedConhost is not null && GetProcessTimes(retainedConhost.SafeHandle, out long beforeBirth, out _, out _, out _) != 0 && beforeBirth == consoleHost.CreationFileTime, "Retained conhost native identity before exit wait");
                        Need(WaitForProcess(retainedConhost!.SafeHandle, 2000) == 0, "Owned conhost actual native exit after FreeConsole");
                        retainedConhostHandle = retainedConhost.SafeHandle;
                        Need(GetProcessTimes(retainedConhostHandle, out long finalBirth, out long finalExit, out _, out _) != 0 && finalBirth == consoleHost.CreationFileTime && finalExit != 0, "Conhost actual native lifetime complete");
                        report["conhostExited"] = true;
                    }
                }

                catch (Exception error) { ((JsonArray)report["cleanupErrors"]!).Add((JsonNode?)JsonValue.Create((string)("Console/conhost: " + error))); }
            }
            try { pendingThread?.Dispose(); report["observerThreadHandleClosed"] = pendingThread is null || pendingThread.IsClosed; }
            catch (Exception error) { ((JsonArray)report["cleanupErrors"]!).Add((JsonNode?)JsonValue.Create((string)("observer thread handle: " + error))); }
            try { retainedConhost?.Dispose(); report["retainedConhostHandleClosed"] = retainedConhostHandle is null || retainedConhostHandle.IsClosed; }
            catch (Exception error) { ((JsonArray)report["cleanupErrors"]!).Add((JsonNode?)JsonValue.Create((string)("retained conhost handle: " + error))); }
            report["holdReleaseAfterFailedCase"] = report["casePassedBeforeCleanup"]?.GetValue<bool>() != true;
            var cleanupClock = Stopwatch.StartNew();
            if (nativePending && !completedProven && file is not null && completed is not null)
            {
                for (int attempt = 0; attempt < 2 && cleanupClock.ElapsedMilliseconds < 5000; attempt++)
                {
                    try
                    {
                        int cancel = CancelIoEx(file, 0); int error = Marshal.GetLastPInvokeError();
                        if (cancel == 0 && error != 1168) ((JsonArray)report["cleanupErrors"]!).Add((JsonNode?)JsonValue.Create((string)("CancelIoEx attempt=" + attempt + " error=" + error)));
                        completedProven = WaitCompleted(completed, Math.Min(2000, 5000 - checked((int)cleanupClock.ElapsedMilliseconds)), report, CancellationToken.None);
                        if (completedProven) break;
                    }
                    catch (Exception error) { ((JsonArray)report["cleanupErrors"]!).Add((JsonNode?)JsonValue.Create((string)(error.ToString()))); }
                }
            }
            report["nativeCompletedBeforeFree"] = !nativePending || completedProven;
            if (nativePending && !completedProven)
            {
                RetainedOwners.Add(file!); RetainedOwners.Add(completed!); RetainedOwners.Add(statusBlock);
                report["nativeStorageRetained"] = true;
                report["retainedResources"] = new JsonArray("file handle", "event handle", "16-byte IO_STATUS_BLOCK");
                ((JsonArray)report["cleanupErrors"]!).Add((JsonNode?)JsonValue.Create((string)("Outer exact private-job owner must reap process; source retained; no UAF/free/delete.")));
            }
            else
            {
                try { file?.Dispose(); report["fileHandleClosed"] = file is null || file.IsClosed; }
                catch (Exception error) { ((JsonArray)report["cleanupErrors"]!).Add((JsonNode?)JsonValue.Create((string)("file: " + error))); }
                try { completed?.Dispose(); report["eventHandleClosed"] = completed is null || completed.IsClosed; }
                catch (Exception error) { ((JsonArray)report["cleanupErrors"]!).Add((JsonNode?)JsonValue.Create((string)("event: " + error))); }
                if (statusBlock != 0) { Marshal.FreeHGlobal(statusBlock); report["nativeStorageFreed"] = true; }
                if (ownedSource && source is not null && createdIdentity is not null)
                {
                    try
                    {
                        ProcessAudit.VerifyRoot(runRoot!, CancellationToken.None);
                        Need(ReadFileIdentity(source) == createdIdentity && Hash(source) == Convert.ToHexString(SHA256.HashData(MicroInput)), "Exact owned source identity/hash before deletion");
                        report["ownedSourceRetainedAsArtifact"] = true; report["ownedSourceIdentityVerified"] = true; report["ownedSourceDeletionAttempted"] = false;
                    }
                    catch (Exception error) { ((JsonArray)report["cleanupErrors"]!).Add((JsonNode?)JsonValue.Create((string)("source retained: " + error))); }
                }
            }
            report["elapsedMilliseconds"] = wall.ElapsedMilliseconds;
            bool pass = report["casePassedBeforeCleanup"]?.GetValue<bool>() == true && ((JsonArray)report["errors"]!).Count == 0 && ((JsonArray)report["cleanupErrors"]!).Count == 0 && report["ownedSourceRetainedAsArtifact"]?.GetValue<bool>() == true && report["ownedSourceIdentityVerified"]?.GetValue<bool>() == true && report["fileHandleClosed"]?.GetValue<bool>() == true && report["eventHandleClosed"]?.GetValue<bool>() == true;
            report["state"] = pass ? "CLI_OPEN_SIGNAL_PASS" : "FAIL"; report["exitCode"] = pass ? 0 : 1;
            if (runRoot is not null)
            {
                try { WriteNew(Path.Combine(runRoot, "child-report.json"), report); }
                catch (Exception error) { ((JsonArray)report["cleanupErrors"]!).Add((JsonNode?)JsonValue.Create((string)("Report persistence failure: " + error))); report["state"] = "FAIL"; report["exitCode"] = 1; Console.Error.WriteLine(error); pass = false; }
            }
            Console.WriteLine(report.ToJsonString());
            report["exitCode"] = pass ? 0 : 1;
        }
        return report["exitCode"]!.GetValue<int>();
    }

    private static bool WaitCompleted(SafeWaitHandle completed, int maximumMilliseconds, JsonObject report, CancellationToken token)
    {
        Need(maximumMilliseconds is > 0 and <= 5000, "Native wait wall bound");
        var watch = Stopwatch.StartNew();
        for (int check = 0; check < 100 && watch.ElapsedMilliseconds < maximumMilliseconds; check++)
        {
            token.ThrowIfCancellationRequested();
            uint result = WaitForSingleObject(completed, checked((uint)Math.Min(50, maximumMilliseconds - watch.ElapsedMilliseconds)));
            if (result == 0) { report["nativeCompletionSignaled"] = true; return true; }
            Need(result == 258, "Native completion wait failed Win32=" + Marshal.GetLastPInvokeError());
            if (check % 20 == 0) Console.Error.WriteLine("helper completion progress=" + check);
        }
        return false;
    }

    private sealed record FileIdentity(ulong Volume, ulong IdLow, ulong IdHigh, long NativeBirth, uint Attributes, string FinalPath)
    {
        internal JsonObject Json() => new() { ["volume"] = Volume.ToString(CultureInfo.InvariantCulture), ["fileIdLow"] = IdLow.ToString(CultureInfo.InvariantCulture), ["fileIdHigh"] = IdHigh.ToString(CultureInfo.InvariantCulture), ["nativeBirth"] = NativeBirth.ToString(CultureInfo.InvariantCulture), ["attributes"] = Attributes, ["absoluteFinalPath"] = FinalPath };
    }
    private static FileIdentity ReadFileIdentity(string path)
    {
        Need((File.GetAttributes(path) & (FileAttributes.Directory | FileAttributes.ReparsePoint)) == 0, "Ordinary non-reparse file");
        using var handle = File.OpenHandle(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
        return ReadFileIdentity(handle);
    }
    private static FileIdentity ReadFileIdentity(SafeFileHandle handle)
    {
        nint memory = Marshal.AllocHGlobal(8192);
        try
        {
            Check(GetFileInformationByHandleEx(handle, 18, memory, 24), "FILE_ID_INFO");
            ulong volume = unchecked((ulong)Marshal.ReadInt64(memory)); ulong low = unchecked((ulong)Marshal.ReadInt64(memory, 8)); ulong high = unchecked((ulong)Marshal.ReadInt64(memory, 16));
            Check(GetFileInformationByHandleEx(handle, 0, memory, 40), "FILE_BASIC_INFO");
            long birth = Marshal.ReadInt64(memory); uint attributes = unchecked((uint)Marshal.ReadInt32(memory, 32));
            uint count = GetFinalPathNameByHandleW(handle, memory, 4096, 0);
            Need(count is > 0 and < 4096, "Bounded final native path");
            string path = Marshal.PtrToStringUni(memory, checked((int)count)) ?? throw new InvalidDataException("native path absent");
            Need(path.StartsWith(@"\\?\", StringComparison.Ordinal), "Normalized DOS volume native path");
            return new(volume, low, high, birth, attributes, Path.GetFullPath(path[4..]));
        }
        finally { Marshal.FreeHGlobal(memory); }
    }
    private static JsonObject Identity(ProcessIdentity value) => new() { ["pid"] = value.Pid, ["nativeBirthFileTime"] = value.CreationFileTime.ToString(CultureInfo.InvariantCulture), ["parentPid"] = value.ParentPid, ["fullCommand"] = value.CommandLine };
    private static ProcessIdentity ReadIdentity(JsonObject value) => new(value["pid"]!.GetValue<uint>(), long.Parse(value["nativeBirthFileTime"]!.GetValue<string>(), CultureInfo.InvariantCulture), value["parentPid"]!.GetValue<uint>(), value["fullCommand"]!.GetValue<string>());
    private static string Hash(string path) { using var input = File.OpenRead(path); return Convert.ToHexString(SHA256.HashData(input)); }
    private static void WriteNew(string path, JsonObject value) { using var output = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.Read); using var text = new StreamWriter(output); text.Write(value.ToJsonString()); text.Flush(); output.Flush(flushToDisk: true); }
    private static void Need(bool condition, string message) { if (!condition) throw new InvalidDataException(message); }
    private static void Check(int value, string context) { if (value == 0) throw new Win32Exception(Marshal.GetLastPInvokeError(), context); }

    [LibraryImport("kernel32.dll", SetLastError = true)] private static partial int GetFileInformationByHandleEx(SafeFileHandle file, int kind, nint buffer, uint bytes);
    [LibraryImport("kernel32.dll", SetLastError = true)] private static partial uint GetFinalPathNameByHandleW(SafeFileHandle file, nint buffer, uint characters, uint flags);
    [LibraryImport("kernel32.dll", SetLastError = true)] private static partial SafeWaitHandle CreateEventW(nint security, int manualReset, int initialState, nint name);
    [LibraryImport("kernel32.dll", SetLastError = true)] private static partial uint WaitForSingleObject(SafeWaitHandle handle, uint milliseconds);
    [LibraryImport("kernel32.dll", SetLastError = true)] private static partial int CancelIoEx(SafeFileHandle file, nint overlapped);
    [LibraryImport("ntdll.dll")] private static partial int NtFsControlFile(SafeFileHandle file, SafeWaitHandle completed, nint apcRoutine, nint apcContext, nint statusBlock, uint code, nint input, uint inputBytes, nint output, uint outputBytes);
    [LibraryImport("kernel32.dll", SetLastError = true)] private static partial int AllocConsole();
    [LibraryImport("kernel32.dll", SetLastError = true)] private static partial int FreeConsole();
    [LibraryImport("kernel32.dll", SetLastError = true)] private static partial nint GetConsoleWindow();
    [LibraryImport("user32.dll", SetLastError = true)] private static partial int ShowWindow(nint window, int command);
    [LibraryImport("user32.dll", SetLastError = true)] private static partial int IsWindowVisible(nint window);
    [LibraryImport("user32.dll", SetLastError = true)] private static partial uint GetWindowThreadProcessId(nint window, out uint pid);
    [LibraryImport("kernel32.dll", SetLastError = true)] private static partial int SetConsoleCtrlHandler(nint handler, int add);
    [LibraryImport("kernel32.dll", SetLastError = true)] private static partial uint GetConsoleProcessList(nint members, uint count);
    [LibraryImport("kernel32.dll", SetLastError = true)] private static partial int GenerateConsoleCtrlEvent(uint kind, uint group);
    [LibraryImport("kernel32.dll", SetLastError = true)] private static partial SafeWaitHandle OpenThread(uint access, int inherit, uint tid);
    [LibraryImport("kernel32.dll", SetLastError = true)] private static partial uint GetProcessIdOfThread(SafeWaitHandle thread);
    [LibraryImport("kernel32.dll", SetLastError = true)] private static partial int GetThreadTimes(SafeWaitHandle thread, out long birth, out long exit, out long kernel, out long user);
    [LibraryImport("kernel32.dll", SetLastError = true)] private static partial int GetThreadIOPendingFlag(SafeWaitHandle thread, out int pending);
    [LibraryImport("kernel32.dll", EntryPoint = "WaitForSingleObject", SetLastError = true)] private static partial uint WaitForThread(SafeWaitHandle thread, uint milliseconds);
    private static string ReadFileMvid(string path)
    {
        using var stream = File.OpenRead(path);
        using var pe = new PEReader(stream);
        MetadataReader metadata = pe.GetMetadataReader();
        return metadata.GetGuid(metadata.GetModuleDefinition().Mvid).ToString("D");
    }
    [LibraryImport("kernel32.dll", SetLastError = true)] private static partial int GetProcessTimes(SafeProcessHandle process, out long birth, out long exit, out long kernel, out long user);
    [LibraryImport("kernel32.dll", EntryPoint = "WaitForSingleObject", SetLastError = true)] private static partial uint WaitForProcess(SafeProcessHandle process, uint milliseconds);
    private static void WriteAtomicNew(string path, JsonObject value)
    {
        string temporary = path + "." + Environment.ProcessId.ToString(CultureInfo.InvariantCulture) + ".tmp";
        using(var output = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
        {
            using var json = new StreamWriter(output);
            json.Write(value.ToJsonString()); json.Flush(); output.Flush(flushToDisk:true);
        }
        File.Move(temporary,path,overwrite:false); // Failed exact temporary remains evidence.
    }
    private static ProcessIdentity DiscoverOwnedConhost(ProcessIdentity self, JsonObject report, CancellationToken token)
    {
        var clock=Stopwatch.StartNew();nint ids=Marshal.AllocHGlobal(32);
        try
        {
            for(int attempt=0;attempt<40&&clock.ElapsedMilliseconds<1000;attempt++)
            {
                token.ThrowIfCancellationRequested();
                Need(QueryCurrentJob(0,3,ids,32,out uint bytes)!=0,"Actual current owned-job process list query");
                uint assigned=unchecked((uint)Marshal.ReadInt32(ids)),count=unchecked((uint)Marshal.ReadInt32(ids,4));
                Need(count<=3&&assigned==count&&bytes>=8+count*8&&bytes<=32,"Bounded exact current job member list");
                ProcessIdentity? candidate=null;int hosts=0;bool selfSeen=false;
                for(int item=0;item<count&&item<3&&clock.ElapsedMilliseconds<1000;item++)
                {
                    token.ThrowIfCancellationRequested();
                    uint pid=checked((uint)Marshal.ReadIntPtr(ids,8+item*8).ToInt64());
                    ProcessIdentity identity=ProcessAudit.Read(pid);
                    if(pid==self.Pid){Need(identity==self,"Actual self native identity in current job");selfSeen=true;continue;}
                    string image=ProcessAudit.ImagePath(identity);
                    Need(identity.ParentPid==self.Pid&&identity.CreationFileTime>=self.CreationFileTime&&image.Equals(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),"conhost.exe"),StringComparison.OrdinalIgnoreCase),"No guessed/unowned pre-CLI job member is accepted");
                    Need(ProcessAudit.Read(pid)==identity,"Conhost PID/native birth/parent/full command stable");
                    report["conhostDiscoveryIdentity"]=Identity(identity);report["conhostDiscoveryImage"]=image;report["conhostDiscoveryImageSha256"]=Hash(image);
                    candidate=identity;hosts++;
                }
                Need(selfSeen && count == hosts + 1, "Exact current snapshot contains self and only verified hosts");
                if(hosts==1){report["conhostDiscovery"]="Actual current owned job + native image/identity/parent";return candidate ?? throw new InvalidDataException("Verified host identity absent");}
                Need(hosts==0,"Ambiguous conhost count");if(attempt%10==0)Console.Error.WriteLine("Actual owned-job conhost discovery "+attempt);Thread.Sleep(25);
            }
            throw new InvalidDataException("UNKNOWN: no independently owned conhost was proved; no synthetic host identity is created.");
        }
        finally{Marshal.FreeHGlobal(ids);}
    }
    [LibraryImport("kernel32.dll",EntryPoint="QueryInformationJobObject",SetLastError=true)]
    private static partial int QueryCurrentJob(nint job,int information,nint buffer,uint size,out uint returned);
}
